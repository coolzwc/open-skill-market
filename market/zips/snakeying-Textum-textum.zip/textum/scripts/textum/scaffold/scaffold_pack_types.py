from __future__ import annotations

SCAFFOLD_PACK_FILENAME = "scaffold-pack.json"
GLOBAL_CONTEXT_FILENAME = "GLOBAL-CONTEXT.md"
SCAFFOLD_TEMPLATE_FILENAME = "scaffold-pack.template.json"


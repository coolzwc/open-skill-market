# Variantes selon le type de créance et cas particuliers

## Table des matières

1. [Variantes selon le type de créance](#variantes-selon-le-type-de-créance)
   - [A. Prestations de services intellectuelles](#a-prestations-de-services-intellectuelles)
   - [B. Vente de marchandises](#b-vente-de-marchandises)
   - [C. Prestations continues](#c-prestations-continues-maintenance-abonnement)
   - [D. Contrat d'entreprise (travaux)](#d-créance-résultant-dun-contrat-dentreprise-travaux)
2. [Adaptation selon les montants](#adaptation-selon-les-montants)
3. [Cas particuliers](#cas-particuliers)
4. [Exemples de formulations](#exemples-de-formulations)

---

## Variantes selon le type de créance

### A. Prestations de services intellectuelles

**Spécificités :**
- Mettre l'accent sur le caractère intellectuel et l'expertise requise
- Détailler les livrables fournis (rapports, études, conseils)
- Insister sur l'impossibilité de "reprendre" les prestations fournies
- Mentionner l'acceptation implicite (usage des conseils, mise en œuvre)

**Formulation :**
```
Les prestations se caractérisent par la mise à disposition du personnel d'[CRÉANCIER],
doté d'une expertise en matière de [domaine], notamment en vue de [objectif].

Ces prestations intellectuelles, par nature immatérielles et non restituables, ont
été intégralement fournies à [DÉBITEUR] qui en a bénéficié pour [usage concret].
```

### B. Vente de marchandises

**Spécificités :**
- Insister sur les bons de livraison signés
- Mentionner la clause de réserve de propriété si applicable
- Détailler les quantités et références des produits
- Indiquer si les marchandises sont toujours en possession du débiteur

**Formulation :**
```
[CRÉANCIER] a livré à [DÉBITEUR] les marchandises suivantes conformément aux bons
de commande :

- [Quantité] [Description produit] pour un montant de [X] € HT
- [...]

Ces marchandises ont été réceptionnées sans réserve par [DÉBITEUR] comme l'attestent les bons de livraison signés par [Nom du réceptionnaire] en date du [date].

Pièce n°[X] : Bons de livraison signés
```

**Si clause de réserve de propriété :**
```
Il est précisé que les marchandises livrées demeurent la propriété d'[CRÉANCIER]
jusqu'au complet paiement du prix, conformément à la clause de réserve de propriété
figurant dans les conditions générales de vente acceptées par [DÉBITEUR].

Toutefois, [CRÉANCIER] sollicite prioritairement le paiement du prix de vente et
se réserve le droit, à défaut de paiement, d'exercer son droit de revendication
des marchandises.
```

### C. Prestations continues (maintenance, abonnement)

**Spécificités :**
- Établir une chronologie des prestations mensuelles
- Montrer la régularité de l'exécution
- Prouver que le service a été utilisé (logs, tickets, interventions)
- Mentionner les règlements antérieurs des premières échéances

**Formulation :**
```
Le contrat prévoit une prestation continue de [type de service] pour une durée de
[durée], moyennant une rémunération forfaitaire mensuelle de [montant] € HT.

[CRÉANCIER] a assuré sans discontinuité l'ensemble des prestations convenues depuis
le [date de début] jusqu'au [date de fin / date actuelle], soit pendant [durée].

Les prestations effectuées incluent notamment :
- [Description des interventions/services assurés]
- [...]

[DÉBITEUR] a d'ailleurs réglé les [X] premières échéances mensuelles, reconnaissant
ainsi la bonne exécution du contrat et le bien-fondé de la créance.

Ce n'est qu'à compter de [date] que [DÉBITEUR] a cessé de s'acquitter de ses
obligations contractuelles, sans la moindre justification.
```

### D. Créance résultant d'un contrat d'entreprise (travaux)

**Spécificités :**
- Mentionner le devis accepté
- Détailler la réception des travaux (avec ou sans réserves)
- Si réserves : prouver qu'elles ont été levées
- Insister sur l'usage des travaux par le débiteur

**Formulation :**
```
À la suite de l'acceptation du devis n°[numéro] du [date] par [DÉBITEUR], [CRÉANCIER]
a procédé à la réalisation des travaux suivants :

- [Description des travaux]

Les travaux ont été achevés le [date] et réceptionnés par [DÉBITEUR] [avec/sans
réserves] le [date].

[Si réserves :]
Les réserves formulées lors de la réception concernaient [description] et ont été
intégralement levées le [date] après intervention complémentaire d'[CRÉANCIER],
comme l'atteste le procès-verbal de levée des réserves.

Pièce n°[X] : Procès-verbal de réception [avec levée des réserves]

[DÉBITEUR] utilise depuis lors les travaux réalisés sans avoir émis la moindre
réclamation quant à leur conformité ou leur qualité.
```

## Adaptation selon les montants

### Petites créances (< 5.000 €)

**Caractéristiques :**
- Procédure simplifiée possible
- Argumentation plus concise
- Moins de développements jurisprudentiels
- Frais article 700 : 1.500 à 2.000 €

**Conseils :**
- Aller à l'essentiel dans la section juridique
- Privilégier les preuves documentaires claires
- Éviter les développements trop longs

### Créances moyennes (5.000 - 50.000 €)

**Caractéristiques :**
- Structure complète recommandée
- Tous les développements juridiques
- Documentation exhaustive
- Frais article 700 : 2.500 à 4.000 €

**Conseils :**
- Suivre le modèle standard de ce skill
- Inclure les références jurisprudentielles
- Développer tous les points de droit

### Grosses créances (> 50.000 €)

**Caractéristiques :**
- Argumentation très développée
- Documentation très fouillée
- Anticipation des contestations possibles
- Frais article 700 : 3.000 à 5.000 €

**Conseils :**
- Développer chaque point avec plusieurs sources jurisprudentielles
- Multiplier les preuves de l'exécution
- Prévoir des arguments subsidiaires
- Envisager une expertise préalable si complexe

## Cas particuliers

### Créance partiellement contestée

**Si le débiteur a émis des réserves sur une partie de la créance :**

```
Il est constant que [DÉBITEUR] a émis des réserves concernant [décrire la partie
contestée] pour un montant de [X] € TTC.

Toutefois, même à considérer ces réserves comme sérieuses (quod non), [DÉBITEUR]
ne conteste nullement le solde de la créance qui s'élève à [MONTANT - X] € TTC.

En conséquence, à tout le moins, [CRÉANCIER] est fondé à solliciter la condamnation
de [DÉBITEUR] au paiement de cette somme non contestée de [MONTANT - X] € TTC.

À titre subsidiaire, [CRÉANCIER] sollicite la condamnation au paiement de l'intégralité
de la créance, les réserves émises par [DÉBITEUR] ne constituant pas une contestation
sérieuse pour les raisons suivantes :

[Développer les arguments démontrant que les réserves ne sont pas fondées]
```

### Créance née d'une relation commerciale établie sans contrat écrit

**En l'absence de contrat formalisé :**

```
Bien qu'aucun contrat écrit n'ait été formalisé entre les Parties, une relation
commerciale habituelle s'est établie entre [CRÉANCIER] et [DÉBITEUR] caractérisée
par :

- Des commandes régulières passées par [DÉBITEUR] auprès d'[CRÉANCIER] depuis
  [date] ;
- L'exécution systématique de ces commandes par [CRÉANCIER] ;
- Le règlement régulier des factures par [DÉBITEUR] jusqu'à [date].

Cette relation commerciale est régie par les conditions générales de vente
d'[CRÉANCIER], dont [DÉBITEUR] a eu connaissance et qu'il a implicitement acceptées
par son comportement, notamment par le règlement des premières factures sans
protestation.

Pièce n°[X] : Conditions générales de vente d'[CRÉANCIER]
Pièce n°[X+1] : Historique des commandes et des règlements

La jurisprudence reconnaît la validité d'un accord de volontés résultant d'un
comportement constant des parties (Cass. com., 16 juin 2015, n° 14-14.729).
```

### Créance avec compensation invoquée par le débiteur

**Si le débiteur prétend avoir une créance en sens inverse :**

```
[DÉBITEUR] a invoqué [dans ses échanges / dans ses courriers] l'existence d'une
prétendue créance à l'encontre d'[CRÉANCIER] d'un montant de [X] € au titre de
[motif allégué].

Cette prétendue créance ne saurait faire obstacle à la condamnation sollicitée
pour les raisons suivantes :

i) Cette créance n'est pas certaine dans son principe : [expliquer pourquoi elle
   n'existe pas ou n'est pas établie] ;

ii) À supposer même qu'elle existe (quod non), elle n'est pas liquide dans son
    quantum : [DÉBITEUR] n'apporte aucun justificatif chiffré de son préjudice
    allégué ;

iii) En tout état de cause, la compensation légale de l'article 1347 du Code civil
     ne peut jouer qu'entre deux dettes certaines, liquides et exigibles, ce qui
     n'est manifestement pas le cas.

La Cour de cassation juge que la compensation ne peut être opposée en référé que
si la créance invoquée en compensation remplit elle-même les conditions de
certitude, liquidité et exigibilité (Cass. com., 8 mars 2016, n° 14-24.425).

Or, en l'espèce, [DÉBITEUR] se contente d'allégations sans apporter le moindre
commencement de preuve de l'existence et du montant de sa prétendue créance.

Par conséquent, aucune compensation ne peut être opposée et [CRÉANCIER] est fondé
à obtenir la condamnation de [DÉBITEUR] au paiement de l'intégralité de sa créance.
```

### Créance avec clause résolutoire ou pénale

**Si le contrat prévoit une clause résolutoire :**

```
Le contrat prévoit à son article [X] une clause résolutoire en cas de non-paiement
à l'échéance :

« [Citer la clause exacte] »

Cette clause résolutoire n'a pas été activée par [CRÉANCIER] qui préfère solliciter
l'exécution forcée du contrat et le paiement du prix.

[CRÉANCIER] se réserve toutefois le droit, en cas de persistance du défaut de
paiement après la présente décision, d'invoquer la résolution du contrat et de
solliciter la restitution des [prestations / marchandises] outre des dommages et
intérêts.
```

## Exemples de formulations

### Formules d'introduction de la relation contractuelle

**Version contrat écrit :**
```
Dans le cadre de son activité, la société [DÉBITEUR] a sollicité [CRÉANCIER] pour
[description] courant [année]. C'est dans ce contexte qu'en date du [date], les
Parties ont convenu de conclure un contrat portant sur [objet].
```

**Version commande sans contrat écrit :**
```
La société [DÉBITEUR] a passé commande auprès d'[CRÉANCIER] de [description]
par [bon de commande / email / appel téléphonique] en date du [date]. Cette commande
a été acceptée par [CRÉANCIER] qui a procédé à [l'exécution / la livraison]
conformément aux termes convenus.
```

**Version relation commerciale établie :**
```
Les Parties entretiennent une relation commerciale établie depuis [date]. Dans ce
cadre, [DÉBITEUR] passe régulièrement commande auprès d'[CRÉANCIER] qui assure
[prestations / livraisons] selon les tarifs et conditions générales de vente
acceptés par [DÉBITEUR].
```

### Formules de description de l'exécution

**Pour prestations intellectuelles :**
```
[CRÉANCIER] a mis à disposition de [DÉBITEUR] son expertise en matière de [domaine]
et a réalisé l'ensemble des missions convenues, à savoir : [liste des livrables].
Ces prestations ont été achevées le [date] et les livrables remis à [DÉBITEUR]
qui les a utilisés pour [usage concret].
```

**Pour vente de marchandises :**
```
[CRÉANCIER] a procédé à la livraison des marchandises commandées en date du [date].
Les marchandises ont été réceptionnées sans réserve par [Nom du réceptionnaire],
[fonction], comme l'attestent les bons de livraison signés ci-joints. [DÉBITEUR]
utilise depuis lors ces marchandises dans le cadre de son activité.
```

**Pour prestations continues :**
```
Durant toute la période du [date] au [date], [CRÉANCIER] a assuré de manière
continue et conforme aux stipulations contractuelles l'ensemble des prestations
de [nature]. Cette exécution est matérialisée par [rapports mensuels / tickets
d'intervention / logs système] démontrant la régularité et la qualité des services
fournis.
```

### Formules de caractérisation de l'absence de contestation

**Version standard :**
```
Il est remarquable que [DÉBITEUR] n'a jamais, à aucun moment, émis la moindre
réserve ou contestation concernant : (i) le principe de la créance, (ii) la qualité
des prestations fournies [ou : des marchandises livrées], (iii) le montant facturé,
(iv) les modalités d'exécution.
```

**Version avec règlements antérieurs :**
```
Au demeurant, [DÉBITEUR] a réglé sans protestation les [X] premières factures
émises par [CRÉANCIER] pour un montant total de [X] €. Ce comportement démontre
sans équivoque la reconnaissance par [DÉBITEUR] du bien-fondé de la créance et
l'absence de tout vice ou défaut dans l'exécution des prestations.
```

**Version avec usage/utilisation :**
```
La preuve la plus évidente de l'absence de contestation sérieuse réside dans le
fait que [DÉBITEUR] continue à utiliser [les prestations fournies / les marchandises
livrées / les services] sans avoir jamais formulé la moindre réclamation. Un tel
comportement est incompatible avec l'existence d'une contestation quelconque.
```

### Formules de conclusion

**Conclusion de la section factuelle :**
```
Ainsi, au regard de l'ensemble de ces éléments factuels, il apparaît que [CRÉANCIER]
a parfaitement exécuté ses obligations contractuelles tandis que [DÉBITEUR] s'est
abstenu de régler les sommes dues, sans justification légitime et en dépit des
multiples relances dont il a fait l'objet.
```

**Conclusion de la section juridique :**
```
En conséquence, au regard de l'ensemble des développements qui précèdent et des
pièces versées aux débats, il apparaît que la créance d'[CRÉANCIER] est certaine
dans son principe, liquide dans son quantum et exigible dans son échéance, sans
qu'aucune contestation sérieuse ne puisse lui être opposée. [CRÉANCIER] est donc
fondé à en obtenir le paiement en référé.
```

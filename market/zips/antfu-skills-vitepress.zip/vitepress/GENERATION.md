# Generation Info

- **Source:** `sources/vitepress`
- **Git SHA:** `d4796a0373eb486766cf48e63fdf461681424d43`
- **Generated:** 2026-01-28

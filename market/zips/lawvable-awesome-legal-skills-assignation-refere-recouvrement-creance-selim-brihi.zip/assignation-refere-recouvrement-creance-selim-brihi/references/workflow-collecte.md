# Workflow de collecte d'informations

## Table des matières

1. [Phase 1 : Identification des parties et de la créance](#phase-1--identification-des-parties-et-de-la-créance)
2. [Phase 2 : Relation contractuelle](#phase-2--relation-contractuelle)
3. [Phase 3 : Exécution et preuve](#phase-3--exécution-et-preuve)
4. [Phase 4 : Relances et absence de paiement](#phase-4--relances-et-absence-de-paiement)
5. [Phase 5 : Documents disponibles](#phase-5--documents-disponibles)
6. [Phase 6 : Éléments procéduraux](#phase-6--éléments-procéduraux)

---

## Phase 1 : Identification des parties et de la créance

**Questions préliminaires à poser à l'utilisateur :**

1. **Qui est le créancier ?**
   - Société ou personne physique ?
   - Si société : dénomination, forme, capital, RCS, siège, dirigeant
   - Si personne physique : nom, prénom, date/lieu naissance, activité, adresse

2. **Qui est le débiteur ?**
   - Mêmes informations que pour le créancier

3. **Quelle est la nature de la créance ?**
   - Prestations de services (quel type ?)
   - Vente de marchandises (quels produits ?)
   - Autre (préciser)

4. **Quel est le montant total impayé ?**
   - Combien de factures ?
   - Montant HT et TTC de chaque facture
   - Dates d'émission et dates d'échéance

## Phase 2 : Relation contractuelle

**Questions sur la genèse de la relation :**

5. **Comment la relation commerciale a-t-elle débuté ?**
   - Date du premier contact
   - Contexte (démarchage, appel d'offres, recommandation)

6. **Existe-t-il un contrat écrit ?**
   - Si oui : date de signature, durée, principales clauses
   - Si non : bons de commande ? Devis acceptés ? Conditions générales ?

7. **Quelles étaient les modalités de paiement convenues ?**
   - Délai (ex : 30 jours, 45 jours fin de mois)
   - Mode (virement, chèque, autre)
   - Clause de pénalités ou intérêts de retard ?

## Phase 3 : Exécution et preuve

**Questions sur la réalisation des prestations/livraisons :**

8. **Les prestations ont-elles été intégralement réalisées ?**
   - Dates de réalisation
   - Description précise de ce qui a été fait/livré

9. **Quelles preuves de l'exécution sont disponibles ?**
   - Bons de livraison signés
   - Rapport d'activité
   - Échanges de mails confirmant la satisfaction
   - Procès-verbaux de réception
   - Attestations
   - Photos/vidéos (si applicable)

10. **Le débiteur a-t-il émis des réserves ou critiques ?**
    - À la réception ?
    - Par la suite ?
    - Par écrit ou oralement ?

## Phase 4 : Relances et absence de paiement

**Questions sur les démarches de recouvrement :**

11. **Des relances ont-elles été effectuées ?**
    - Dates des relances
    - Modalités (courrier RAR, email, appel téléphonique)
    - Réponses reçues ou non

12. **Le débiteur a-t-il donné des explications pour le non-paiement ?**
    - Difficultés financières ?
    - Contestation de la qualité ?
    - Contestation du montant ?
    - Aucune explication ?

13. **Y a-t-il eu des règlements partiels ?**
    - Si oui : montants et dates
    - Sur quelles factures ?

## Phase 5 : Documents disponibles

**Inventaire des pièces justificatives :**

14. **Quels documents sont disponibles ?**
    - [ ] Extrait Kbis du créancier (récent)
    - [ ] Extrait Kbis du débiteur (récent)
    - [ ] Contrat signé ou bons de commande
    - [ ] Conditions générales de vente
    - [ ] Toutes les factures impayées
    - [ ] Grand-livre comptable
    - [ ] Preuves d'exécution (bons de livraison, rapport, etc.)
    - [ ] Relances (courriers, emails)
    - [ ] Échanges de correspondances
    - [ ] Preuves de règlements partiels

## Phase 6 : Éléments procéduraux

**Questions pratiques :**

15. **Quel est le tribunal compétent ?**
    - Lieu du siège social du débiteur
    - Clause attributive de juridiction ?

16. **Quelle date d'audience est visée ?**
    - Délai minimum : 15 jours après signification
    - Vérifier le calendrier du tribunal

17. **Coordonnées de l'avocat du créancier ?**
    - Nom, prénom, barreau, adresse, téléphone, email, toque

18. **Y a-t-il des éléments contextuels particuliers ?**
    - Litige parallèle entre les parties
    - Procédure collective en cours
    - Autres créanciers impayés
    - Difficultés financières connues du débiteur

# Structure de la Requête CPH

## Table des matières

1. [EN-TÊTE](#en-tête)
2. [PARTIE 1 : Identification des parties](#partie-1--identification-des-parties)
3. [PARTIE 2 : Avertissements légaux](#partie-2--avertissements-légaux)
4. [PARTIE 3 : Rappel des éléments essentiels](#partie-3--rappel-des-éléments-essentiels)
5. [PARTIE 4 : Plaise au Conseil](#partie-4--plaise-au-conseil)
6. [PARTIE 5 : Rappel des faits et de la procédure](#partie-5--rappel-des-faits-et-de-la-procédure)
7. [PARTIE 6 : Exposé des motifs des demandes](#partie-6--exposé-des-motifs-des-demandes)
8. [PARTIE 7 : Demandes connexes](#partie-7--demandes-connexes)
9. [PARTIE 8 : Par ces motifs](#partie-8--par-ces-motifs)
10. [PARTIE 9 : Signature et pièces](#partie-9--signature-et-pièces)

---

## Structure de la requête

La requête doit suivre cette structure précise :

### EN-TÊTE
```
REQUÊTE AUX FINS DE SAISINE DU CONSEIL DE PRUD'HOMMES
VALANT PREMIÈRES CONCLUSIONS EN DEMANDE
(Articles 57 du Code de procédure civile et L.1411-1 et suivants
et R.1452-1 et suivants du Code du travail)

CONSEIL DE PRUD'HOMMES DE : [Ville]
ADRESSE : [Adresse complète du CPH]

CONVOCATION DEVANT : Bureau de conciliation et d'orientation

Cadre réservé au conseil de prud'hommes
Numéro RG :
Section :
Chambre :
Audience :
```

### PARTIE 1 : IDENTIFICATION DES PARTIES

#### A. DEMANDEUR(ESSE)
Indiquer de manière structurée :
- Nom et prénom
- Date et lieu de naissance
- Nationalité
- Adresse
- Profession
- Date d'embauche
- Nature de l'engagement
- Cadre/Non-cadre
- Rémunération mensuelle brute moyenne
- Ancienneté
- Procédure de licenciement (dates de convocation, entretien, notification)
- Motif de la rupture

Si le salarié est représenté par un avocat, indiquer :
```
Ayant pour Avocat :
Maître [Prénom NOM]
Avocat au Barreau de [Ville]
[Adresse du cabinet]
Tel : [téléphone] / Email : [email]
```

#### B. DÉFENDEUR(ESSE)
Indiquer de manière structurée :
- Dénomination
- Forme juridique
- Siège social
- RCS et numéro
- SIRET
- Effectif
- Convention collective
- Code APE
- Prise en la personne de son représentant légal domicilié audit siège

### PARTIE 2 : AVERTISSEMENTS LÉGAUX

Inclure obligatoirement les avertissements suivants :

```
* * *
TRÈS IMPORTANT
* * *

Il est rappelé au défendeur que, faute pour lui de comparaître, il s'expose à ce qu'une décision
soit rendue contre lui et sur les seuls éléments fournis par son adversaire.

Par ailleurs, il est rappelé que, conformément à l'article R. 1453-1 du Code du travail, les parties
se défendent elles-mêmes et ont la faculté de se faire assister ou représenter.

Il est enfin rappelé qu'en vertu de l'article R. 1453-2 du même Code :
« Les personnes habilitées à assister ou à représenter les parties sont :
1° Les salariés ou les employeurs appartenant à la même branche d'activité ;
2° Les défenseurs syndicaux ;
3° Le conjoint, le partenaire lié par un pacte civil de solidarité ou le concubin ;
4° Les avocats.

L'employeur peut également se faire assister ou représenter par un membre de l'entreprise
ou de l'établissement fondé de pouvoir ou habilité à cet effet.

Le représentant, s'il n'est pas avocat, doit justifier d'un pouvoir spécial. Devant le bureau
de conciliation et d'orientation, cet écrit doit l'autoriser à concilier au nom et pour le compte
du mandant, et à prendre part aux mesures d'orientation. »

Les pièces sur lesquelles la demande est fondée sont énumérées suivant bordereau annexé
au présent acte.
```

### PARTIE 3 : RAPPEL DES ÉLÉMENTS ESSENTIELS

Présenter sous forme de tableau récapitulatif :
- Date d'embauche
- Nature de l'engagement
- Cadre/Non-cadre
- Qualification
- Salaire brut moyen
- Lieu de travail
- Ancienneté
- Date de convocation à entretien préalable
- Date de l'entretien préalable
- Date de notification du licenciement
- Motif invoqué

### PARTIE 4 : PLAISE AU CONSEIL

```
PLAISE AU CONSEIL
```

### PARTIE 5 : RAPPEL DES FAITS ET DE LA PROCÉDURE

Cette section doit être narrative et chronologique. Elle comprend généralement :

#### I. PRÉSENTATION DES RELATIONS ENTRE LES PARTIES
- Date d'embauche et fonction initiale
- Évolution de la relation de travail
- Contexte de travail
- Convention collective applicable

#### II. SUR L'ÉVOLUTION DES RELATIONS CONTRACTUELLES
- Déroulement de la relation de travail
- Qualité du travail fourni
- Absences d'incidents antérieurs (si applicable)
- Contexte ayant mené au licenciement

#### III. SUR LE LICENCIEMENT
- Date de convocation à l'entretien préalable (+ pièce n°X)
- Date et déroulement de l'entretien préalable
- Griefs évoqués lors de l'entretien
- Date de notification du licenciement (+ pièce n°X)
- Motifs invoqués dans la lettre de licenciement
- Contestation par le salarié

#### IV. SUR LA TENTATIVE DE RÉSOLUTION AMIABLE (si applicable)
- Date de la mise en demeure
- Réponse de l'employeur (ou absence de réponse)

**Conclusion de cette section :**
"C'est dans ce contexte que [M./Mme] [Nom] entend saisir le Conseil de prud'hommes de céans."

### PARTIE 6 : EXPOSÉ DES MOTIFS DES DEMANDES

Cette partie est le cœur juridique de la requête. Elle doit être structurée en sections avec des sous-titres clairs.

**Introduction :**
```
Le/La requérant(e) sollicite du Conseil de Prud'hommes qu'il reçoive l'intégralité de ses moyens
et prétentions, à savoir :
```

Puis lister les demandes principales avec leurs montants :
- Requalification du licenciement pour faute grave en licenciement sans cause réelle et sérieuse
- Indemnité pour licenciement sans cause réelle et sérieuse : [montant] €
- Indemnité légale de licenciement : [montant] €
- Indemnité compensatrice de préavis : [montant] €
- Congés payés afférents : [montant] €
- Autres demandes le cas échéant

#### Section I : LA REQUALIFICATION DU LICENCIEMENT POUR FAUTE GRAVE EN LICENCIEMENT SANS CAUSE RÉELLE ET SÉRIEUSE

Cette section doit comprendre :

**A. RAPPEL DES PRINCIPES EN DROIT**

Citer les articles pertinents du Code du travail :

```
EN DROIT,

Aux termes de l'article L. 1232-1 du Code du travail, tout licenciement pour motif personnel
doit être justifié par une cause réelle et sérieuse.

Selon l'article L. 1234-1 du Code du travail, lorsque le licenciement est justifié par une faute
grave, le salarié n'a droit ni à un préavis, ni à une indemnité de licenciement.

La faute grave est celle qui résulte d'un fait ou d'un ensemble de faits imputables au salarié
qui constituent une violation des obligations découlant du contrat de travail ou des relations
de travail d'une importance telle qu'elle rend impossible le maintien du salarié dans l'entreprise
même pendant la durée du préavis (Cass. soc., 27 septembre 2007, n° 06-43867).

La preuve des griefs reprochés doit être rapportée exclusivement par l'employeur (Cass. soc.,
Pôle 6, 11ème Chambre, 17 janvier 2023, n° 20/07683).

Le juge ne peut, dès lors que l'employeur s'est placé sur le terrain disciplinaire, requalifier
le licenciement en un licenciement pour insuffisance professionnelle (Cass. soc., Pôle 6,
11ème Chambre, 17 janvier 2023, n° 20/07683).
```

**B. APPLICATION AU CAS D'ESPÈCE - ANALYSE DES GRIEFS**

Pour chaque grief invoqué par l'employeur, faire une analyse structurée :

1. **Grief n°1 : [intitulé du grief]**

   *Grief allégué par l'employeur :*
   Exposer précisément ce que l'employeur reproche.

   *Contestation par le salarié :*
   - Exposer pourquoi ce grief est contesté
   - Apporter des éléments factuels contraires
   - Citer des pièces au dossier le cas échéant

   *Analyse juridique :*
   - Expliquer pourquoi ce grief ne caractérise pas une faute grave
   - Citer de la jurisprudence pertinente si disponible

2. **Grief n°2 : [etc.]**

**C. SUR L'ABSENCE DE CARACTÉRISATION DE LA FAUTE GRAVE**

Conclure sur le fait que :
- Les griefs ne sont pas établis, OU
- Les griefs sont établis mais ne caractérisent pas une faute grave
- L'employeur n'a pas rapporté la preuve
- Le maintien du salarié dans l'entreprise n'était pas impossible

**D. SUR LES IRRÉGULARITÉS DE PROCÉDURE (si applicable)**

Si des irrégularités existent (délai non respecté, convocation irrégulière, etc.), les exposer ici avec les articles du Code du travail applicables.

**Conclusion de cette section :**
```
En conséquence, le licenciement pour faute grave notifié à [M./Mme] [Nom] ne repose pas
sur une cause réelle et sérieuse et doit être requalifié en licenciement sans cause réelle et sérieuse.
```

#### Section II : LES DEMANDES INDEMNITAIRES

**A. INDEMNITÉ POUR LICENCIEMENT SANS CAUSE RÉELLE ET SÉRIEUSE**

*EN DROIT :*

Distinguer selon l'effectif de l'entreprise :

**Si l'entreprise emploie moins de 11 salariés :**
```
Conformément à l'article L. 1235-5 du Code du travail, si le licenciement d'un salarié survient
pour une cause qui n'est pas réelle et sérieuse dans une entreprise employant habituellement
moins de onze salariés, le juge peut proposer la réintégration du salarié dans l'entreprise,
avec maintien de ses avantages acquis.

Si l'une des parties refuse cette réintégration, le juge octroie au salarié une indemnité
à la charge de l'employeur, dont le montant est compris entre un minimum d'un mois de salaire
et un maximum de deux mois de salaire par année d'ancienneté, sans pouvoir être inférieure
à trois mois de salaire.
```

**Si l'entreprise emploie 11 salariés ou plus :**
```
Conformément à l'article L. 1235-3 du Code du travail, si le licenciement d'un salarié survient
pour une cause qui n'est pas réelle et sérieuse, dans une entreprise employant habituellement
au moins onze salariés, le juge peut proposer la réintégration du salarié dans l'entreprise,
avec maintien de ses avantages acquis.

Si l'une ou l'autre des parties refuse cette réintégration, le juge octroie au salarié
une indemnité à la charge de l'employeur. Cette indemnité ne peut être inférieure aux salaires
des six derniers mois. Elle est due sans préjudice, le cas échéant, de l'indemnité de licenciement
prévue à l'article L. 1234-9.

Le montant de l'indemnité est déterminé en fonction du préjudice subi, compte tenu notamment :
- du salaire de référence ;
- de l'ancienneté du salarié ;
- de l'âge du salarié et de ses difficultés à retrouver un emploi ;
- des circonstances de la rupture.

Le minimum légal est fixé par l'article L. 1235-3-1 du Code du travail [citer le barème
en fonction de l'ancienneté].
```

*EN L'ESPÈCE :*

Calculer et justifier le montant demandé :
```
[M./Mme] [Nom] justifie d'une ancienneté de [X] ans et [X] mois au moment de son licenciement.
Son salaire de référence s'élève à [montant] euros brut.

Conformément au barème légal [ou : Compte tenu de son ancienneté, de son âge, des circonstances
du licenciement], [M./Mme] [Nom] sollicite la condamnation de la société [Nom] au paiement
de la somme de [montant] euros à titre d'indemnité pour licenciement sans cause réelle et sérieuse.
```

**B. INDEMNITÉ LÉGALE DE LICENCIEMENT**

*EN DROIT :*
```
En application de l'article R. 1234-2 du Code du travail, l'indemnité légale de licenciement
ne peut être inférieure aux montants suivants :
- Un quart de mois de salaire par année d'ancienneté pour les années jusqu'à dix ans ;
- Un tiers de mois de salaire par année d'ancienneté pour les années à partir de dix ans.

L'indemnité légale de licenciement est calculée sur la base du salaire de référence défini
par l'article R. 1234-4 du Code du travail, à savoir la rémunération la plus favorable entre :
- La moyenne mensuelle des douze derniers mois précédant le licenciement ;
- Le tiers des trois derniers mois (les primes et gratifications exceptionnelles ou annuelles
étant alors prises en compte en proportion du temps de travail effectué).
```

*EN L'ESPÈCE :*

Faire le calcul détaillé :
```
[M./Mme] [Nom] cumule [X] ans et [X] mois d'ancienneté.
Son salaire de référence est de [montant] euros brut.

Calcul :
[Détailler le calcul selon les tranches]

Total de l'indemnité légale de licenciement : [montant] euros.
```

**C. INDEMNITÉ COMPENSATRICE DE PRÉAVIS ET CONGÉS PAYÉS AFFÉRENTS**

*EN DROIT :*
```
L'article L. 1234-5 du Code du travail dispose que le licenciement est notifié au salarié
par lettre recommandée avec avis de réception. Sous réserve de l'application de l'article
L. 1234-1, la lettre de licenciement comporte l'énoncé du ou des motifs invoqués par l'employeur.
Elle doit également préciser la durée du préavis.

En application de l'article L. 1234-1 du Code du travail, lorsque le licenciement est motivé
par une faute grave, le salarié n'a droit ni au préavis ni à l'indemnité compensatrice de préavis.

Toutefois, dès lors que la faute grave n'est pas caractérisée et que le licenciement est requalifié
en licenciement sans cause réelle et sérieuse, le salarié a droit au paiement de l'indemnité
compensatrice de préavis ainsi qu'aux congés payés afférents.

La durée du préavis est déterminée par [la convention collective applicable / les dispositions
légales / l'usage / le contrat de travail].
```

*EN L'ESPÈCE :*

Calculer l'indemnité :
```
En l'espèce, [M./Mme] [Nom] relève [de la convention collective [Nom], laquelle prévoit
un préavis de [durée] / des dispositions légales qui prévoient un préavis de [durée]].

Son salaire brut mensuel moyen étant de [montant] euros, l'indemnité compensatrice de préavis
s'élève à [montant] euros brut.

Les congés payés afférents au préavis représentent 10% de cette somme, soit [montant] euros.
```

**D. RAPPEL DE SALAIRE POUR MISE À PIED CONSERVATOIRE (si applicable)**

Si le salarié a été mis à pied à titre conservatoire et que la faute grave n'est pas caractérisée :

*EN DROIT :*
```
La mise à pied conservatoire ne constitue pas une sanction mais une simple mesure d'attente
permettant à l'employeur de procéder aux investigations nécessaires avant de notifier le licenciement.

Dès lors que la faute grave n'est pas caractérisée, la mise à pied conservatoire est injustifiée
et le salarié doit percevoir le rappel de salaire correspondant à la période de mise à pied.
```

*EN L'ESPÈCE :*
```
[M./Mme] [Nom] a été mis(e) à pied à titre conservatoire du [date] au [date], soit pendant [X] jours.

La faute grave n'étant pas caractérisée, cette mise à pied est injustifiée et [M./Mme] [Nom]
sollicite le rappel de salaire correspondant, soit la somme de [montant] euros brut, outre
[montant] euros au titre des congés payés afférents.
```

**E. DOMMAGES-INTÉRÊTS POUR PRÉJUDICES DISTINCTS (si applicable)**

Si des préjudices spécifiques existent (conditions du licenciement, harcèlement, atteinte
à la réputation, etc.) :

*EN DROIT :*
```
En application de l'article 1240 du Code civil (ancien article 1382), tout fait quelconque
de l'homme, qui cause à autrui un dommage, oblige celui par la faute duquel il est arrivé
à le réparer.

Le salarié peut solliciter des dommages-intérêts en réparation de préjudices distincts
du préjudice résultant de la perte de l'emploi, dès lors que ces préjudices sont établis.
```

*EN L'ESPÈCE :*

Exposer les préjudices :
```
[M./Mme] [Nom] a subi un préjudice distinct du fait [de la brutalité du licenciement /
des conditions humiliantes de la rupture / de l'atteinte à sa réputation / etc.].

[Développer les circonstances et le préjudice subi]

En réparation de ce préjudice, [M./Mme] [Nom] sollicite la condamnation de la société [Nom]
au paiement de la somme de [montant] euros à titre de dommages-intérêts.
```

**F. REMBOURSEMENT DES ALLOCATIONS CHÔMAGE (si applicable)**

*EN DROIT :*
```
En application des articles L. 1235-4 et L. 1235-5 du Code du travail, sauf si le salarié
a moins de deux ans d'ancienneté ou si l'entreprise emploie habituellement moins de onze salariés,
le juge ordonne le remboursement par l'employeur aux organismes concernés (notamment Pôle emploi)
de tout ou partie des allocations de chômage versées au salarié licencié, du jour du licenciement
au jour du jugement, dans la limite de six mois d'allocations.
```

*EN L'ESPÈCE :*
```
[M./Mme] [Nom] cumule plus de deux ans d'ancienneté.
L'entreprise emploie plus de onze salariés.

En conséquence, il y a lieu d'ordonner à la société [Nom] de rembourser aux organismes
concernés (notamment Pôle emploi) les allocations de chômage versées à [M./Mme] [Nom]
depuis le [date] dans la limite de six mois d'allocations.
```

### PARTIE 7 : DEMANDES CONNEXES

**A. SUR L'EXÉCUTION PROVISOIRE**

*EN DROIT :*
```
En application de l'article R. 1454-28 du Code du travail : « À moins que la loi ou le règlement
n'en dispose autrement, les décisions du conseil de prud'hommes ne sont pas exécutoires de droit
à titre provisoire. Le conseil de prud'hommes peut ordonner l'exécution provisoire de ses décisions. »

Sont de droit, exécutoires à titre provisoire, notamment :
- Le jugement qui n'est pas susceptible d'appel que par suite d'une demande reconventionnelle ;
- Le jugement qui ordonne la remise d'un certificat de travail, de bulletins de paie
ou de toute pièce que l'employeur est tenu de délivrer.
```

*EN L'ESPÈCE :*

Justifier la demande :
```
Les demandes [de M./Mme] [Nom] sont justifiées et viennent réparer un préjudice important.

Il existe un risque de non-paiement de la condamnation, justifiant une mesure exécutoire.

En conséquence, [M./Mme] [Nom] sollicite que l'exécution provisoire soit ordonnée pour l'ensemble
de la décision à intervenir.
```

**B. AU TITRE DE L'ARTICLE 700 DU CODE DE PROCÉDURE CIVILE ET DES DÉPENS**

*EN DROIT :*
```
En application de l'article 700 du Code de procédure civile : « Lorsqu'il paraît inéquitable
de laisser à la charge d'une partie les sommes exposées par elle et non comprises dans les dépens,
le juge peut condamner l'autre partie à lui payer le montant qu'il détermine. »
```

*EN L'ESPÈCE :*
```
[M./Mme] [Nom] justifie de ce qu'une tentative de résolution amiable a été tentée auprès
de l'employeur.

[Il/Elle] justifie également de ce que les mesures prises à son encontre sont abusives.

Il serait donc inéquitable de laisser à sa charge les sommes exposées par [lui/elle] dans le cadre
de cette procédure.

En conséquence, [M./Mme] [Nom] sollicite la condamnation de la société [Nom] à [lui/lui] verser
la somme de [montant] euros au titre de l'article 700 du Code de procédure civile.
```

**C. CONDAMNATION AU REMBOURSEMENT DES INDEMNITÉS DE PÔLE EMPLOI (si applicable)**

Reprendre les éléments de la section II.F ci-dessus.

**D. REMISE DES DOCUMENTS DE FIN DE CONTRAT (si applicable)**

Si des documents n'ont pas été remis :

```
ORDONNER la remise des documents conformes à la décision suivants sous astreinte de [15] euros
par document et par jour de retard :
- Ensemble des bulletins de paie rectifiés
- Attestation employeur destinée à France Travail
- Certificat de travail conforme
- Solde de tout compte
```

### PARTIE 8 : PAR CES MOTIFS

Récapituler toutes les demandes de manière claire et chiffrée :

```
PAR CES MOTIFS

[M./Mme] [Nom] demande à Mesdames, Messieurs les conseillers de :

■ JUGER que le licenciement pour faute grave notifié le [date] est dépourvu de cause réelle
et sérieuse ;

■ CONDAMNER la société [Nom] à verser à [M./Mme] [Nom] les sommes suivantes :

Sur l'exécution du contrat de travail (si applicable) :
- [Montant] euros à titre de rappel de salaire pour [motif]
- [Montant] euros au titre des congés payés afférents
- [Montant] euros à titre de [autre demande]

Sur la rupture du contrat de travail :
- [Montant] euros à titre d'indemnité pour licenciement sans cause réelle et sérieuse
- [Montant] euros à titre d'indemnité légale de licenciement
- [Montant] euros à titre d'indemnité compensatrice de préavis
- [Montant] euros au titre des congés payés afférents au préavis
- [Montant] euros à titre de rappel de salaire pour mise à pied conservatoire injustifiée
- [Montant] euros au titre des congés payés afférents
- [Montant] euros à titre de dommages-intérêts en réparation du préjudice distinct subi

■ CONDAMNER la société [Nom] à s'acquitter des dépens ;

■ ORDONNER la remise des documents conformes à la décision suivants sous astreinte
de [15] euros par document et par jour de retard :
- Ensemble des bulletins de paie rectifiés
- Attestation employeur destinée à France Travail
- Certificat de travail conforme
- Solde de tout compte

■ ORDONNER l'exécution provisoire de la décision à intervenir et la capitalisation des intérêts.
```

### PARTIE 9 : SIGNATURE ET PIÈCES

Conclure avec :

```
Pièces jointes à la présente requête :

Pièce n°1 : Contrat de travail du [date]
Pièce n°2 : [Description]
Pièce n°3 : [Description]
[etc.]

Fait à [Ville]
Le [date]

[Signature du salarié ou de son avocat]

[M./Mme] [Nom]
[ou]
Maître [Nom de l'avocat]
```

# Understanding Statutory Structure

This guide explains common organizational patterns in statutes to help you navigate unfamiliar legal texts efficiently.

---

## The Legal Hierarchy

### Statutes, Regulations, and Rules

| Level | Created By | Characteristics |
|-------|------------|-----------------|
| **Constitution** | Founders/amendments | Supreme law; statutes must conform |
| **Statute** | Legislature | Formal enactment; framework-level |
| **Regulation** | Agency | Implements statutes; detailed rules |
| **Guidance** | Agency | Interpretation; not legally binding |

**Key Relationship:** Statutes authorize agencies to create regulations. The regulation is where operational details often appear.

### Why This Matters

When researching compliance requirements:
1. Start with the statute (framework)
2. Find implementing regulations (details)
3. Check agency guidance (practical interpretation)
4. Research case law (judicial interpretation)

Reading only the statute gives an incomplete picture.

---

## Common Statutory Architecture

Most comprehensive statutes follow this pattern:

### 1. Title and Citation

**What It Contains:**
- Official name of the statute
- Citation format (e.g., "42 U.S.C. § 1234")
- Short title for common reference

**Why It Matters:**
- Proper citation is essential for legal research
- Short titles help locate related materials

### 2. Purpose or Findings Section

**What It Contains:**
- Legislative intent
- Problems the statute addresses
- Policy goals

**Why It Matters:**
- Guides interpretation of ambiguous provisions
- Courts reference purpose when choosing between readings
- Often labeled "Findings," "Purpose," or "Declaration of Policy"

**Example Language:**
> "The Legislature finds that consumers have a right to privacy and that..."

### 3. Definitions Section

**What It Contains:**
- Statutory meanings of key terms
- Technical definitions
- Scope limitations

**Why It Matters:**
- Words may have meanings that differ from common usage
- Definitions control interpretation throughout the statute
- Missing this section leads to misreading

**Structure:**
- Often numbered or lettered alphabetically
- May include cross-references to other laws
- "Means" indicates exhaustive definition
- "Includes" may indicate non-exhaustive examples

### 4. Applicability/Scope Section

**What It Contains:**
- Who must comply (covered entities)
- Thresholds (revenue, volume, activity)
- Geographic scope
- Temporal scope (effective dates)

**Why It Matters:**
- Determines whether the statute applies at all
- Often the most business-critical section
- Thresholds can be conjunctive (AND) or disjunctive (OR)

**Common Threshold Types:**
- Revenue-based ($25M annual revenue)
- Volume-based (100,000 consumers)
- Activity-based (50% revenue from regulated activity)
- Entity-type (applies to "controllers," "developers," etc.)

### 5. Substantive Requirements

**What It Contains:**
- Core obligations imposed by the statute
- Rights granted to protected parties
- Prohibited conduct
- Required disclosures

**Structure:**
- Often divided into sections for different obligation types
- May separate "rights" from "duties"
- May include timing requirements

### 6. Exemptions Section

**What It Contains:**
- Entities excluded from coverage
- Data types excluded
- Activities excluded
- Federal law preemption carve-outs

**Types of Exemptions:**
- **Entity exemptions:** Entire organization is exempt
- **Data exemptions:** Specific data types excluded; entity still complies for other data
- **Activity exemptions:** Specific activities excluded
- **Conditional exemptions:** Exempt if certain conditions are met

**Common Federal Law Carve-outs:**
- HIPAA (health information)
- GLBA (financial services)
- FCRA (credit reporting)
- FERPA (educational records)
- COPPA (children's online privacy)

### 7. Enforcement Section

**What It Contains:**
- Who can enforce (AG, agency, private parties)
- Enforcement procedures
- Investigation powers
- Cure/correction periods

**Why It Matters:**
- Shapes practical compliance priority
- Private right of action significantly increases risk
- Cure periods affect response urgency

### 8. Penalties Section

**What It Contains:**
- Civil penalty amounts
- Criminal penalties (if any)
- Per-violation vs. aggregate caps
- Factors affecting penalty determination

**Common Structures:**
- Per-violation amounts ($7,500, $10,000)
- Enhanced penalties for knowing violations
- Separate treatment of subsequent violations
- Penalty funds (where money goes)

### 9. Effective Dates

**What It Contains:**
- When the statute takes effect
- Phase-in periods for specific provisions
- Delayed application for certain entities

**Why It Matters:**
- Requirements may not yet be in force
- Different provisions may have different dates
- Cure periods may expire on specific dates

---

## Reading Strategies by Section Type

### For Definitions
1. Read the entire definitions section first
2. Create a reference sheet of key terms
3. Note definitions that reference other definitions
4. Mark terms that differ from common usage

### For Applicability
1. Identify all threshold criteria
2. Determine if thresholds are AND or OR
3. Check for entity-type limitations
4. Note effective dates

### For Substantive Requirements
1. Categorize by type (disclosure, operational, technical)
2. Extract time-based requirements separately
3. Note conditional requirements ("if X, then Y")
4. Cross-reference with definitions

### For Exemptions
1. Distinguish entity vs. data exemptions
2. Check for conditional exemptions
3. Note delayed application vs. permanent exemption
4. Verify federal law carve-outs apply to your situation

### For Enforcement
1. Identify all potential enforcers
2. Note cure period existence and duration
3. Check for private right of action
4. Research agency enforcement history

---

## Navigating Complex Statutes

### Cross-References

When you encounter language like:
- "As defined in Section X"
- "Subject to the requirements of Section Y"
- "Notwithstanding Section Z"

**Action:** Stop and read the referenced section before continuing.

### Incorporation by Reference

Statutes may incorporate external standards:
- "As defined by the FTC"
- "In accordance with NIST guidelines"
- "Consistent with [federal law]"

**Action:** Locate and understand the referenced standard.

### Amendment Tracking

Statutes change over time:
- Check for pending amendments
- Note sunset provisions
- Track regulatory updates
- Monitor enforcement actions for interpretation guidance

---

## Section Identification Tips

### Common Section Titles

| What You're Looking For | Common Section Titles |
|------------------------|----------------------|
| Definitions | "Definitions," "Terms," "Meaning of Terms" |
| Scope | "Applicability," "Scope," "Application," "Coverage" |
| Requirements | "Duties," "Obligations," "Requirements," "Responsibilities" |
| Rights | "Consumer Rights," "Rights," "Protected Rights" |
| Exemptions | "Exemptions," "Exceptions," "Exclusions," "Limitations" |
| Enforcement | "Enforcement," "Administration," "Implementation" |
| Penalties | "Penalties," "Violations," "Civil Penalties," "Remedies" |
| Effective Date | "Effective Date," "Implementation," "Applicability Date" |

### When Sections Are Unnamed

Some statutes use only numbers/letters without descriptive titles:
1. Skim the first sentence of each section
2. Look for definition-style language ("As used in this chapter...")
3. Look for applicability language ("This chapter applies to...")
4. Look for penalty amounts (signals enforcement section)

---

## Checklist: Navigating a New Statute

- [ ] Locate and read the definitions section
- [ ] Identify applicability thresholds
- [ ] Note the effective date(s)
- [ ] Identify the enforcement agency
- [ ] Check for exemptions that might apply
- [ ] Identify cure period (if any)
- [ ] Note private right of action status
- [ ] Check for implementing regulations
- [ ] Identify cross-references to follow

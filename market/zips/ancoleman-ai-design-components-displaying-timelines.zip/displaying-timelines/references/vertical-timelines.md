# Vertical Timeline Patterns

Implementation patterns for vertical timelines with connecting lines, markers, and alternating layouts.

## Basic Structure

[HTML and CSS structure for vertical timelines]

## Alternating Layout

[Left-right alternating event cards]

## Marker Styles

[Dot, icon, and custom marker implementations]

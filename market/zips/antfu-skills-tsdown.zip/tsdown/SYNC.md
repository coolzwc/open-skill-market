# Sync Info

- **Source:** `vendor/tsdown/skills/tsdown`
- **Git SHA:** `76b612274f6bf4efb9f1b9285ea2aad56556df67`
- **Synced:** 2026-01-31

# Canons of Statutory Construction

Canons of construction are interpretive principles that courts use when statutory language is ambiguous. While not binding rules, courts find them persuasive and often cite them in opinions.

---

## Textual Canons

These canons focus on the words of the statute itself.

### 1. Plain Meaning Rule

**Principle:** Courts assume statutory words mean what an ordinary person would understand them to mean. If the words are clear and unambiguous, the court need not inquire further.

**Application:**
- Begin with ordinary understanding based on common usage
- If meaning is clear, stop there
- Only resort to other interpretive tools if ambiguity exists

**Limitation:** Technical statutes may use terms with specialized meanings that differ from ordinary usage.

---

### 2. General-Terms Canon

**Principle:** General terms are given their full and fair scope without being arbitrarily limited.

**Rationale:** Legislatures often create broad categories (e.g., "dangerous weapons," "any property") without anticipating everything that might fit within them.

**Example:** A statute allowing seizure of "any property, including money" was construed to include both real and personal property—the general term "property" was not limited to the specific example given.

---

### 3. Negative-Implication Canon (Expressio Unius Est Exclusio Alterius)

**Principle:** The expression of one thing implies the exclusion of others.

**Application:** When a statute specifies certain items, other items not mentioned are presumed to be excluded.

**Example:** If a statute lists specific exemptions (A, B, and C), an entity claiming exemption D will likely fail—the explicit listing implies D was intentionally excluded.

**Caution:** This canon can be overused. Sometimes legislatures list examples without intending to exclude all others.

---

### 4. Whole-Act Rule

**Principle:** The text should be construed as a whole. Each part of a statute provides context for the others.

**Application:**
- Read provisions in light of surrounding sections
- Don't interpret one section in a way that contradicts another
- The statute's overall structure informs individual provisions

**Result:** Often establishes that only one possible meaning is compatible with usage elsewhere in the statute.

---

### 5. Presumption of Consistent Usage

**Principle:** The same word or phrase used repeatedly in a statute should have the same meaning throughout.

**Application:** If "personal data" is defined in Section 2, that definition should apply wherever "personal data" appears in the statute.

**Corollary (Meaningful Variation):** When the legislature uses DIFFERENT terms, presume they intended different meanings.

---

### 6. Surplusage Canon

**Principle:** Every word in a statute should have meaning. Courts avoid interpretations that render words superfluous.

**Example:** A statute requiring "any written communication, including any notice, circular, advertisement, letter, or communication by radio or television."

- If "communication" meant ANY written communication, the specific list would be surplusage
- Better interpretation: "communication" refers to oral statements via radio/TV, giving each word independent meaning

**Application:** When choosing between interpretations, prefer the one that gives effect to all words.

---

### 7. Associated Words Canon (Noscitur a Sociis)

**Principle:** Words are known by the company they keep. Associated words inform one another's meaning.

**Application:** When interpreting a term grouped with other terms, look at the shared characteristics of the group to determine the term's scope.

**Example:** In "case, controversy, suit, or proceeding," the specific terms suggest the general term should be interpreted in a legal/judicial context, not broadly to include any dispute.

---

### 8. Ejusdem Generis

**Principle:** When a general term follows a list of specific terms, the general term is limited to items of the same class as the specific ones.

**Example:** "Dogs, cats, birds, or other animals" — "other animals" likely means other domestic pets, not elephants or whales.

**Application:** Identify the common characteristic of the specific items, then limit the general term to that category.

---

### 9. Rule Against Surplusage in Lists

**Principle:** When a statute provides a list, each item should add something distinct. Overlapping interpretations are disfavored.

**Application:** If interpreting Item A to include Item B's scope, Item B becomes surplusage. Prefer interpretations where each item has independent meaning.

---

## Purpose Canons

These canons look beyond the text to the statute's goals.

### 1. Preamble and Purpose Clauses

**Principle:** Many statutes include preambles or purpose sections that explicitly state legislative intent.

**Application:** When choosing between plausible interpretations, prefer the one that advances the stated purpose.

**Limitation:** Purpose clauses inform interpretation but generally don't create independent obligations.

---

### 2. Presumption Against Ineffectiveness

**Principle:** Favor interpretations that further rather than obstruct the statute's purpose.

**Example:** The Supreme Court held that a "misdemeanor crime of domestic violence" need not include "domestic relationship" as an element. Requiring this element would have made the law "a dead letter in two-thirds of the States" and frustrated Congress's manifest purpose.

**Application:** Reject interpretations that would make the statute ineffective or inapplicable to the problems it was designed to address.

---

### 3. Avoiding Absurdity

**Principle:** Courts will not adopt interpretations that produce absurd results, even if textually supportable.

**Application:** If literal reading leads to outcomes the legislature clearly did not intend, courts may depart from the text.

**Limitation:** This canon is used sparingly; mere policy disagreement doesn't make a result "absurd."

---

### 4. Remedial Statutes

**Principle:** Statutes designed to remedy a problem or protect a class of persons are liberally construed to achieve their remedial purpose.

**Application:** Consumer protection laws, civil rights laws, and similar remedial statutes are interpreted broadly to effectuate their protective goals.

---

### 5. Rule of Lenity

**Principle:** Criminal statutes are strictly construed in favor of the defendant.

**Application:** When a penal statute is ambiguous about whether conduct is criminal, resolve the ambiguity in the defendant's favor.

**Rationale:** Fair notice requires that people know what conduct is prohibited before being punished for it.

---

### 6. In Pari Materia

**Principle:** Statutes on the same subject matter should be construed together and harmonized where possible.

**Application:** When interpreting a bank fraud statute, courts may look to how analogous mail fraud statutes have been interpreted.

**Result:** Creates consistency across related statutory schemes.

---

## Deference Canons

These canons address whose interpretation prevails.

### 1. Agency Deference

**Principle:** Courts defer to reasonable agency interpretations of statutes they administer.

**Application:** When an agency charged with administering a statute issues regulations or guidance, courts often accept that interpretation if it's reasonable.

**Limitation:** Deference applies to ambiguous statutes; courts don't defer when the statute's meaning is clear.

---

### 2. Stare Decisis

**Principle:** Prior judicial interpretations of a statute carry significant weight.

**Application:** If a court has previously interpreted statutory language, later courts will generally follow that interpretation unless there's strong reason to depart.

---

## Application Tips

### When to Use Canons

1. **After establishing ambiguity:** Canons help resolve ambiguity; they're less relevant when meaning is clear
2. **In combination:** Multiple canons often apply; weigh them against each other
3. **With awareness of limitations:** Canons are tools, not rules; courts sometimes decline to apply them

### Common Canon Conflicts

- **Expressio unius** may conflict with the purpose of a remedial statute
- **Plain meaning** may conflict with **avoiding absurdity**
- **Agency deference** may conflict with **rule of lenity** in criminal contexts

### Documenting Canon Application

When analyzing a statute:
1. Identify applicable canons
2. Note which interpretation each canon supports
3. Weigh canons against each other
4. Explain reasoning for preferred interpretation

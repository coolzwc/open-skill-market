# Sync Info

- **Source:** `vendor/turborepo/skills/turborepo`
- **Git SHA:** `1caed6d1b018fc29b98c14e661a574f018a922f6`
- **Synced:** 2026-01-31

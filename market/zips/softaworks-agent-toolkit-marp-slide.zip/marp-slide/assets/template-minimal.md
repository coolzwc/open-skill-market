---
marp: true
theme: default
paginate: true
---

<style>
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@300;400;500&display=swap');

:root {
  --color-background: #ffffff;
  --color-foreground: #2c2c2c;
  --color-heading: #1a1a1a;
  --color-accent: #e0e0e0;
  --font-default: 'Noto Sans JP', 'Hiragino Kaku Gothic ProN', 'Meiryo', sans-serif;
}

section {
  background-color: var(--color-background);
  color: var(--color-foreground);
  font-family: var(--font-default);
  font-weight: 300;
  box-sizing: border-box;
  position: relative;
  line-height: 1.8;
  font-size: 24px;
  padding: 60px 80px;
}

h1, h2, h3, h4, h5, h6 {
  font-weight: 400;
  color: var(--color-heading);
  margin: 0;
  padding: 0;
}

h1 {
  font-size: 60px;
  line-height: 1.3;
  text-align: left;
  font-weight: 300;
  letter-spacing: 0.02em;
}

h2 {
  font-size: 42px;
  margin-bottom: 40px;
  font-weight: 400;
  letter-spacing: 0.01em;
}

h3 {
  color: var(--color-foreground);
  font-size: 28px;
  margin-top: 32px;
  margin-bottom: 16px;
  font-weight: 400;
}

ul, ol {
  padding-left: 32px;
}

li {
  margin-bottom: 14px;
  line-height: 1.7;
}

footer {
  font-size: 14px;
  color: #999999;
  position: absolute;
  left: 80px;
  right: 80px;
  bottom: 40px;
  text-align: center;
}

section.lead {
  display: flex;
  flex-direction: column;
  justify-content: center;
  text-align: center;
}

section.lead h1 {
  margin-bottom: 32px;
  text-align: center;
}

section.lead p {
  font-size: 24px;
  color: var(--color-foreground);
  font-weight: 300;
}

hr {
  border: none;
  border-top: 1px solid var(--color-accent);
  margin: 40px 0;
}
</style>

<!-- _class: lead -->

# プレゼンテーション

シンプル＆ミニマル

---

## アジェンダ

- トピック1
- トピック2
- トピック3

---

## スライドタイトル

- ポイント1
- ポイント2
- ポイント3

---
name: makepad-skills
description: "Makepad UI development skills for Rust apps: setup, patterns, shaders, packaging, and troubleshooting."
source: "https://github.com/ZhangHanDong/makepad-skills"
risk: safe
---

# Makepad Skills

## Overview

Makepad UI development skills for Rust apps: setup, patterns, shaders, packaging, and troubleshooting.

## When to Use This Skill

Use this skill when you need to work with makepad ui development skills for rust apps: setup, patterns, shaders, packaging, and troubleshooting..

## Instructions

This skill provides guidance and patterns for makepad ui development skills for rust apps: setup, patterns, shaders, packaging, and troubleshooting..

For more information, see the [source repository](https://github.com/ZhangHanDong/makepad-skills).

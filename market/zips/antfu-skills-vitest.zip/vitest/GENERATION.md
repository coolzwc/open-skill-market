# Generation Info

- **Source:** `sources/vitest`
- **Git SHA:** `4a7321e10672f00f0bb698823a381c2cc245b8f7`
- **Generated:** 2026-01-28

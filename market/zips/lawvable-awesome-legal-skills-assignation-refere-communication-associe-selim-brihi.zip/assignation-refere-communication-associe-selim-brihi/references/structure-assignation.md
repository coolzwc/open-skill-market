# Structure de l'Assignation en Référé - Communication de Documents Sociaux

## Table des matières

1. [En-tête](#1-en-tête)
2. [Avertissements obligatoires](#2-avertissements-obligatoires)
3. [Corps de l'assignation : PLAISE AU PRESIDENT](#3-corps-de-lassignation--plaise-au-president)
4. [Dispositif : PAR CES MOTIFS](#4-dispositif--par-ces-motifs)
5. [Bordereau de pièces](#5-bordereau-de-pièces)

---

## 1. En-tête

```
ASSIGNATION EN REFERE
DEVANT MADAME OU MONSIEUR
LE PRESIDENT DU TRIBUNAL [DE COMMERCE / DES ACTIVITES ECONOMIQUES] DE [VILLE]

L'AN DEUX MIL [ANNÉE] ET LE [DATE EN TOUTES LETTRES]

A LA DEMANDE DE

[Identité complète : Monsieur/Madame [NOM Prénom], né(e) le [date] à [ville (CP)],
de nationalité [nationalité], demeurant [adresse complète]]

Ayant pour Avocat : Maître [Prénom NOM]
Avocat au Barreau de [Ville]
[Adresse]
Tél : [téléphone]
Toque [X XXX]
Courriel : [email]

J'AI L'HONNEUR D'INFORMER

[Identité complète du défendeur]

Qu'il/elle est convoqué(e) le [jour] [date] à [heure]

En effet, faute de parvenir à une résolution amiable du litige, un procès lui est intenté,
pour les raisons ci-après exposées, devant Madame ou Monsieur le Président du Tribunal
[de commerce / des activités économiques] de [Ville], statuant en référé, et siégeant
en ladite ville [adresse complète du tribunal].
```

## 2. Avertissements obligatoires

Reprendre intégralement le bloc standard :

```
TRÈS IMPORTANT

Vous êtes tenus de constituer avocat avant l'audience ci-dessus indiquée pour être
représenté devant la formation des référés du tribunal [de commerce / des activités
économiques] de [Ville].

A défaut vous vous exposez à ce qu'une ordonnance soit rendue contre vous sur les seuls
éléments fournis par votre adversaire.

Il vous est rappelé que l'article 861-2 du Code de procédure civile dispose :

« Sans préjudice des dispositions de l'article 68, la demande incidente tendant à l'octroi
d'un délai de paiement en application de l'article 1343-5 du code civil peut être formée
par requête faite, remise ou adressée au greffe, où elle est enregistrée. L'auteur de cette
demande doit justifier avant l'audience que l'adversaire en a eu connaissance par lettre
recommandée avec demande d'avis de réception. Les pièces que la partie invoque à l'appui
de sa demande de délai de paiement sont jointes à la requête.

L'auteur de cette demande incidente peut ne pas se présenter à l'audience, conformément
au second alinéa de l'article 446-1. Dans ce cas, le juge ne fait droit aux demandes
présentées contre cette partie que s'il les estime régulières, recevables et bien fondées. »

Les pièces sur lesquelles la demande est fondée sont indiquées en fin d'acte selon
bordereau annexé.
```

## 3. Corps de l'assignation : PLAISE AU PRESIDENT

### 1. LES FAITS

#### 1.1. Présentation des Parties et de la société [NOM]

Inclure systématiquement :
- Identité précise des parties
- Présentation de la société (création, forme juridique, activité, siège)
- Composition du capital et répartition des parts/actions avec pourcentages exacts
- Qualité du demandeur (associé à hauteur de X%)
- Qualité du défendeur (gérant, président, etc.)
- Références aux pièces (Kbis, statuts)

#### 1.2. [Titre contextuel selon le dossier]

Décrire la chronologie factuelle conduisant au litige. Exemples de sous-sections :
- Les demandes de communication restées sans réponse
- Le contexte de séparation entre associés (si pertinent)
- Les échanges entre conseils

#### 1.3. Le manque de transparence opposé par [le défendeur] à [le demandeur]

Détailler chronologiquement chaque manquement :
- Convocations avec documents incomplets ou parcellaires
- Pages manquantes dans les documents communiqués
- Feuilles blanches jointes au lieu des documents annoncés
- Absence de réponse aux demandes de communication

Pour chaque incident, préciser :
- La date
- La nature du document demandé vs. communiqué
- Les pages manquantes avec nombre total de pages
- La référence aux pièces

#### 1.4. [Section optionnelle sur la mauvaise foi caractérisée]

Si applicable, documenter :
- Tentatives de contournement de l'obligation (ex: invitation à consulter sur place au domicile personnel)
- Jugements antérieurs constatant la mauvaise foi
- Création de sociétés concurrentes
- Pression pour céder les parts
- Tout élément démontrant une stratégie d'obstruction

#### 1.5. Conclusion factuelle

Conclure que le demandeur n'a toujours pas pu exercer ses droits et saisit le tribunal en référé.

### 2. DISCUSSION

#### 2.1. SUR L'INJONCTION DE COMMUNICATION DES DOCUMENTS SUR LE FONDEMENT DE L'ARTICLE L. 238-1 DU CODE DE COMMERCE

##### 2.1.1. Rappel des textes applicables

Citer intégralement :

```
Aux termes de l'article L. 238-1 du code de commerce :

« Lorsque les personnes intéressées ne peuvent obtenir la production, la communication
ou la transmission des documents visés aux articles L. 221-7, L. 223-26, L. 225-115,
L. 225-116, L. 225-117, L. 225-118, L. 225-129, L. 225-129-5, L. 225-129-6, L. 225-135,
L. 225-136, L. 225-138, L. 225-177, L. 225-184, L. 228-69, L. 237-3 et L. 237-26,
elles peuvent demander au président du tribunal statuant en référé soit d'enjoindre
sous astreinte au liquidateur ou aux administrateurs, gérants, et dirigeants de les
communiquer, soit de désigner un mandataire chargé de procéder à cette communication.

La même action est ouverte à toute personne intéressée ne pouvant obtenir du liquidateur,
des administrateurs, gérants ou dirigeants communication d'une formule de procuration
conforme aux prescriptions fixées par décret en Conseil d'Etat ou des renseignements
exigés par ce décret en vue de la tenue des assemblées.

Lorsqu'il est fait droit à la demande, l'astreinte et les frais de procédure sont à la
charge des administrateurs, des gérants, des dirigeants ou du liquidateur mis en cause. »
[surlignement en gras ajouté]
```

Puis citer l'article spécifique selon la forme sociale :

**Pour SARL - Article L. 223-26 alinéa 4 :**
```
« L'associé peut, en outre, et à toute époque, obtenir communication, dans les conditions
fixées par décret en Conseil d'Etat, des documents sociaux déterminés par ledit décret
et concernant les trois derniers exercices. »
```

##### 2.1.2. Réunion des conditions

Structurer en points numérotés (i, ii, iii, iv) :

**i. Qualité d'associé**
- Le demandeur est associé de la société à hauteur de X%
- Référence aux pièces

**ii. Documents relevant du droit de communication**
Liste standard pour SARL :
- Le rapport de gestion
- L'inventaire
- Les comptes annuels
- Le texte des résolutions proposées
- Les rapports soumis aux assemblées générales
- Les procès-verbaux des assemblées générales
- Préciser : "sur les trois derniers exercices [années]"

**iii. Demande visant personnellement le dirigeant**
- La demande vise [Nom] en sa qualité de [fonction]

**iv. Obstruction caractérisée**
- Rappel synthétique des manquements décrits dans les faits
- Référence à la section factuelle

Conclure :
```
Par conséquent, [le demandeur] exerce une action remplissant les conditions de l'article
L.238-1 du code de commerce auprès de Madame ou Monsieur le Président du Tribunal [de
commerce / des activités économiques] de céans afin qu'il soit enjoint à [le défendeur]
la communication des documents listés ci-dessus.
```

##### 2.1.3. Éléments contextuels (optionnel mais recommandé)

Si la mauvaise foi est caractérisée, utiliser des puces (ð) pour souligner :
- Le contexte conflictuel
- Les condamnations antérieures du défendeur
- Les tentatives d'évitement de l'obligation
- Les indices de dissimulation
- Les créations de sociétés parallèles
- La pression exercée sur le demandeur

#### 2.2. SUR LES FRAIS IRRÉPÉTIBLES

Formulation standard :
```
Afin de faire valoir simplement ses droits dans le cadre de la présente action,
[le demandeur] a été contraint(e) d'engager des frais irrépétibles qu'il serait
inéquitable de laisser à sa charge.

Il/Elle demande en conséquence au Président du tribunal de céans de condamner
[le défendeur] au paiement de la somme de [montant] euros en application de
l'article 700 du code de procédure civile.
```

Montant habituel : 5.000 euros

## 4. Dispositif : PAR CES MOTIFS

```
PAR CES MOTIFS

Vu l'article L. 238-1 du code de commerce,
Vu l'article [L. 223-26 / autre selon forme sociale] du code de commerce,
Vu l'assignation et les pièces qui y sont annexées,

Il est demandé au Président du Tribunal [de commerce / des activités économiques]
de [Ville] de :

- ENJOINDRE à [Monsieur/Madame NOM Prénom] de communiquer à [Monsieur/Madame NOM Prénom]
  l'ensemble des documents afférents aux trois derniers exercices [années] de la société
  [NOM], listés ci-dessous :

  - Le rapport de gestion ;
  - L'inventaire ;
  - Les comptes annuels ;
  - Le texte des résolutions proposées ;
  - Les rapports soumis aux assemblées générales ;
  - Les procès-verbaux des assemblées générales.

- ASSORTIR l'injonction d'une astreinte de [montant] euros par jour de retard pendant
  un délai de [durée] jours [7 jours après / à compter de] la signification de la
  décision à intervenir ;

- CONDAMNER [Monsieur/Madame NOM Prénom] au paiement à [Monsieur/Madame NOM Prénom]
  de la somme de [montant] euros au titre de l'article 700 du code de procédure civile
  ainsi qu'aux entiers dépens.

SOUS TOUTES RESERVES
```

Paramètres habituels d'astreinte :
- Montant : 1.000 à 2.000 euros par jour
- Durée : 60 jours
- Point de départ : "7 jours après la signification"

## 5. Bordereau de pièces

```
LISTE DES PIECES A L'APPUI
___________________________________________________________________

Pièce n°1 : Extrait Kbis de la société [NOM]
Pièce n°2 : Statuts de la société [NOM]
[...]
```

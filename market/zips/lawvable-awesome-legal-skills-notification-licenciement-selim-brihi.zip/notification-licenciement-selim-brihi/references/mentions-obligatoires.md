# Mentions Obligatoires - Notification de Licenciement (Droit Français)

## 1. EN-TÊTE ET COORDONNÉES

### Coordonnées de l'employeur (en haut à gauche)
- Raison sociale complète
- Adresse du siège social
- Téléphone / Fax
- Email
- Informations RCS (forme juridique, capital, numéro RCS, code APE)

### Coordonnées du salarié (en haut à droite)
- Civilité + Prénom + NOM
- Adresse complète du domicile

### Informations de la lettre
- Lieu et date : `[VILLE], LE [DATE]`
- **OBLIGATOIRE** : `Lettre recommandée avec avis de réception N° [NUMÉRO] + pli simple`
- Objet : `Notification d'un licenciement pour faute grave` (ou autre motif)
- Pièce(s) jointe(s) : `Portabilité des droits en matière de prévoyance`
- N° réf : [Numéro de référence interne]

## 2. FORMULE D'APPEL
- `Madame,` ou `Monsieur,`

## 3. RÉFÉRENCE À L'ENTRETIEN PRÉALABLE (OBLIGATOIRE)
Toujours commencer par rappeler l'entretien préalable :
```
Nous vous avons convoqué(e) à un entretien préalable qui était prévu le [DATE], [présence/absence du salarié + éventuellement assistance].
```

Variantes selon la situation :
- `auquel vous ne vous êtes pas présenté(e).`
- `auquel vous étiez assisté(e) par [préciser]`
- `Lors de cet entretien préalable, qui s'est déroulé en visioconférence, vous n'étiez pas assisté par un conseiller du salarié.`

## 4. NOTIFICATION DE LA DÉCISION (OBLIGATOIRE)
Formule type :
```
Malgré les observations que vous nous avez formulées, nous avons décidé de vous licencier pour faute grave.

Nous vous informons, par la présente, de notre décision de vous licencier pour les motifs suivants :
```

OU (si absence à l'entretien) :
```
Nous vous informons, par la présente, de notre décision de vous licencier pour les motifs suivants :
```

## 5. EXPOSÉ DES MOTIFS (CRITIQUE - À PERSONNALISER)

### Principes essentiels :
1. **PRÉCISION MAXIMALE** : Les motifs doivent être détaillés, précis, datés et circonstanciés
2. **ORDRE CHRONOLOGIQUE** : Présenter les faits dans un ordre logique
3. **CUMUL DES GRIEFS** : Préciser si les faits, pris isolément ET cumulativement, justifient le licenciement
4. **GRAVITÉ** : Expliquer en quoi les faits rendent impossible la poursuite du contrat

### Formules d'introduction courantes :
- `Nous avons à déplorer plusieurs agissements fautifs de votre part.`
- `L'analyse des faits révèle un enchaînement de manquements graves et intentionnels, qui, pris isolément comme cumulativement, rendent impossible votre maintien dans l'entreprise.`
- `Ainsi que nous vous l'avons exposé lors de l'entretien, les motifs de licenciement sont les suivants :`

### Structure type d'un grief :
```
[Description factuelle du manquement]
[Date(s) précise(s)]
[Contexte et circonstances]
[Conséquences pour l'entreprise]
[Qualification juridique]
```

### Exemples de griefs bien motivés :

**Absence du poste / Abandons non justifiés :**
```
Vous vous êtes absentée de votre travail à plusieurs reprises sans motif légitime, sans autorisation de notre part et sans nous en avoir informé.

Le [DATE PRÉCISE], vous avez quitté votre poste de travail pour vaquer à des occupations personnelles sur vos heures et durant vos jours de travail.
```

**Manquements graves avec mise en danger :**
```
Le [DATE], vous avez sorti de notre parc automobile un véhicule qui était dans une zone spécifique (véhicule non conforme) appartenant à notre entreprise qui était impropre à la circulation car dangereux, immobilisé pour des raisons de sécurité et devait faire l'objet de réparations avant de pouvoir être remis en service, malgré l'interdiction qui vous avait été faite de l'utiliser, vous mettant vous-même ainsi que les autres usagers de la route en danger.

Les forces de l'ordre ont dû intercepter ce véhicule et avons découvert que vous étiez au volant du véhicule dit dangereux.

Vous êtes volontairement passé(e) outre nos instructions, risquant de causer un accident et de mettre en cause la responsabilité civile et pénale de [NOM ENTREPRISE].
```

**Insuffisance professionnelle / Non-réalisation des missions :**
```
Vous avez été embauché(e) en qualité de [POSTE] au sein de notre société par contrat de travail à durée indéterminée à compter du [DATE].

Vos fonctions consistaient, notamment, à :
- [Liste détaillée des missions]
- [...]

Or, votre travail depuis [PÉRIODE], s'est avéré largement insuffisant.

[Détails précis des manquements avec dates et exemples]

Malgré les demandes et rappels de notre part, [description des conséquences].

Cela a eu une incidence négative sur les objectifs mensuels qui vous étaient assignés et qui n'ont pas pu être réalisés, ni en [ANNÉE], ni en [ANNÉE], du fait de votre manque de travail, de votre manque d'implication et de l'absence de réalisation de vos missions.
```

**Falsification / Fraude :**
```
Nos vérifications ont établi que [description précise du fait frauduleux avec dates].

Cette pratique délibérée constitue une violation grave de vos obligations contractuelles et une atteinte à la confiance qui doit exister entre employeur et salarié.
```

**Violation d'obligations contractuelles (clause de mobilité, etc.) :**
```
Vous êtes conduit à vous déplacer régulièrement, sur des périodes de plus ou moins longue durée, à des distances variées, conformément à la clause de mobilité qui figure dans votre contrat de travail, auquel vous avez expressément consenti, et qui est rédigée en ces termes :

[Citation de la clause]

Pour autant, vous avez récemment décidé d'agir en violation de cette obligation contractuelle de mobilité.

[Description détaillée des faits avec dates et circonstances]

Votre comportement constitue un grave manquement à vos obligations contractuelles.
```

### Formule de conclusion des griefs :
```
L'ensemble de ces faits constituent des fautes graves rendant impossible la poursuite de votre contrat de travail, même durant le préavis.
```

OU :
```
Ces divers manquements graves de votre part nous conduisent à rompre votre contrat de travail avec effet immédiat, sans préavis ni indemnité de licenciement.
```

## 6. CONSÉQUENCES DU LICENCIEMENT (OBLIGATOIRE)

### Rupture immédiate pour faute grave :
```
Votre contrat de travail à durée indéterminée sera rompu à la date d'envoi de la présente lettre, sans qu'aucune indemnité de licenciement ou de préavis ne vous soit versée.
```

OU :
```
En conséquence, eu égard à la gravité des faits reprochés, nous sommes contraints de vous notifier votre licenciement pour faute grave.

Votre contrat de travail à durée indéterminée sera rompu à la date d'envoi de la présente lettre, sans qu'aucune indemnité de licenciement ou de préavis ne vous soit versée.
```

### Mention de la mise à pied conservatoire (si applicable) :
```
Vous avez fait par ailleurs l'objet d'une mise à pied à titre conservatoire qui vous a été notifiée le [DATE]. Dès lors, la période non travaillée du [DATE] à la date de la notification de votre licenciement ne sera pas rémunérée.
```

## 7. DOCUMENTS DE FIN DE CONTRAT (OBLIGATOIRE)
```
Votre certificat de travail, reçu pour solde de tout compte et attestation destinée à France Travail vous seront adressés prochainement par courrier recommandé avec avis de réception.
```

OU :
```
Nous tenons à votre disposition votre certificat de travail, votre reçu pour solde de tout compte et votre attestation destinée à France travail.
```

## 8. RESTITUTION DU MATÉRIEL (OBLIGATOIRE SI APPLICABLE)
```
Nous vous demandons de nous rendre le matériel professionnel encore en votre possession et de nous communiquer les identifiants et mots de passe permettant d'y accéder.
```

OU :
```
Nous vous remercions de bien vouloir nous restituer dès réception de la présente lettre l'ensemble du matériel professionnel en votre possession.
```

## 9. PORTABILITÉ DE LA PRÉVOYANCE (OBLIGATOIRE)
```
Vous trouverez également ci-joint, en deux exemplaires, la note d'information sur la portabilité des droits en matière de prévoyance, dont un exemplaire devra nous être retourné signé.
```

OU version longue :
```
Vous pourrez conserver temporairement, sous réserve de votre prise en charge par le régime d'assurance chômage, le bénéfice des avantages en matière de prévoyance et de mutuelle complémentaires en vigueur dans notre entreprise.

Le maintien de ce régime sera d'une durée maximum de 12 (douze) mois et son financement sera assuré intégralement par un système de mutualisation : à ce titre, vous n'aurez aucune cotisation à acquitter.

Il vous appartient de vous rapprocher dans les meilleurs délais de notre organisme assureur afin de faire valoir votre droit au maintien en justifiant des conditions requises pour en bénéficier.

Les garanties maintenues seront celles applicables au sein de notre société pendant votre période de chômage, de sorte que toute évolution collective desdites garanties à compter de votre départ vous sera opposable.
```

## 10. CLAUSE DE NON-CONCURRENCE (SI APPLICABLE)
```
Nous renonçons expressément à la clause de non-concurrence qui figure dans votre contrat de travail et vous dispensons totalement de l'interdiction de concurrence qui y est définie. Vous êtes donc délié(e) de vos obligations à ce titre.
```

OU :
```
Vous êtes expressément délié(e) de votre obligation de non concurrence prévue à votre contrat de travail, de sorte que vous ne percevrez pas d'indemnité de non concurrence.

Nous vous rappelons que vous restez toutefois astreint à une obligation de confidentialité, même après le terme de votre contrat de travail.
```

## 11. DROIT À DEMANDE DE PRÉCISIONS (OBLIGATOIRE)
```
Enfin, vous pouvez faire une demande de précision des motifs du licenciement énoncés dans la présente lettre par l'envoi d'une lettre recommandée avec avis de réception ou remise contre récépissé, dans les 15 jours suivant sa notification.

Nous avons la faculté d'y donner suite dans un délai de 15 jours après réception de votre demande. Nous pouvons également prendre l'initiative d'apporter des précisions à ces motifs dans un délai de 15 jours suivant la notification du licenciement.
```

OU version longue :
```
Vous pouvez faire une demande de précision des motifs du licenciement énoncés dans la présente lettre, dans les quinze jours suivant sa notification par lettre recommandée avec avis de réception ou remise contre récépissé. Nous avons la faculté d'y donner suite dans un délai de quinze jours après réception de votre demande, par lettre recommandée avec avis de réception ou remise contre récépissé. Nous pouvons également, le cas échéant, et dans les mêmes formes, prendre l'initiative d'apporter des précisions à ces motifs dans un délai de quinze jours suivant la notification du licenciement.
```

## 12. FORMULE DE POLITESSE (OBLIGATOIRE)
```
Veuillez agréer, Madame/Monsieur, l'expression de notre considération distinguée.
```

OU :
```
Nous vous prions d'agréer, Madame/Monsieur [NOM], l'expression de nos salutations distinguées.
```

## 13. SIGNATURE
```
La Direction de Ressources Humaines,
```

OU :
```
[Prénom NOM]
[Fonction]
```

---

## POINTS D'ATTENTION CRITIQUES

### ⚠️ ERREURS À ÉVITER ABSOLUMENT :

1. **Motifs vagues ou généraux** : "Vous n'avez pas respecté vos obligations" → INSUFFISANT
2. **Absence de dates précises** : Toujours dater les faits reprochés
3. **Faits non établis** : Ne mentionner que des faits vérifiables et documentés
4. **Griefs nouveaux** : Ne pas ajouter de griefs non évoqués lors de l'entretien préalable
5. **Qualification juridique erronée** : Bien distinguer faute grave / faute lourde / motif personnel
6. **Oubli des mentions obligatoires** : LRAR, entretien préalable, documents de fin de contrat, délai de 15 jours

### ✅ BONNES PRATIQUES :

1. **Accumuler les preuves** : Photos, emails, témoignages, rapports
2. **Chronologie claire** : Présenter les faits dans l'ordre avec dates
3. **Lien de causalité** : Expliquer l'impact des fautes sur l'entreprise
4. **Proportionnalité** : La sanction doit être proportionnée aux faits
5. **Cohérence** : Les griefs doivent être cohérents avec le motif invoqué
6. **Précision maximale** : Plus c'est détaillé, mieux c'est pour se défendre en justice

### 📋 CHECKLIST FINALE :

- [ ] En-tête complet avec coordonnées employeur et salarié
- [ ] Mention LRAR + pli simple
- [ ] Référence à l'entretien préalable
- [ ] Motifs précis, datés et circonstanciés
- [ ] Conséquences du licenciement (rupture immédiate, absence d'indemnités)
- [ ] Documents de fin de contrat
- [ ] Restitution du matériel
- [ ] Portabilité de la prévoyance
- [ ] Clause de non-concurrence (si applicable)
- [ ] Droit à demande de précisions (15 jours)
- [ ] Formule de politesse
- [ ] Signature

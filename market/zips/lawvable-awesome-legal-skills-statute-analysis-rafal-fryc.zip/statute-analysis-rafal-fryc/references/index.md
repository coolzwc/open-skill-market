# Statute Guide Documentation Reference

## Reference Documents

| Document | Description |
|----------|-------------|
| [Canons of Construction](canons_of_construction.md) | Detailed guide to textual and purpose canons with examples |
| [Practical Lessons](practical_lessons.md) | Lessons learned from analyzing multiple statutes |
| [Statutory Structure Guide](statutory_structure.md) | Common organizational patterns in statutes |

## Quick Links

### Operator Words Reference
See [SKILL.md](../SKILL.md#the-operator-words) for the complete operator words table.

### Canons Quick Reference
See [canons_of_construction.md](canons_of_construction.md) for detailed explanations and case examples.

### Checklists
See [SKILL.md](../SKILL.md#quick-reference-checklist) for before/during/after reading checklists.

## Source Materials

This skill synthesizes content from:
- Academic guides on statutory interpretation (Clark, Capella University)
- Practical experience analyzing 19+ state privacy laws
- Comparison of automated extraction against professional legal analyses
- Cross-jurisdictional compliance analysis projects

# Workflow de rédaction et informations à collecter

## Table des matières

1. [Workflow de rédaction](#workflow-de-rédaction)
2. [Informations à collecter](#informations-à-collecter)
3. [Questions types à poser](#questions-types-à-poser)
4. [Points clés de rédaction](#points-clés-de-rédaction)
5. [Adaptation selon la forme sociale](#adaptation-selon-la-forme-sociale)
6. [Éléments contextuels renforceurs](#éléments-contextuels-renforceurs)
7. [Erreurs à éviter](#erreurs-à-éviter)

---

## Workflow de rédaction

1. **Collecter les informations** (voir section suivante)
2. **Vérifier la forme sociale** pour adapter les articles
3. **Établir la chronologie** des demandes et refus
4. **Documenter chaque manquement** avec précision
5. **Rédiger les faits** de manière factuelle et chronologique
6. **Structurer la discussion juridique** (4 conditions de L. 238-1)
7. **Formuler le dispositif** avec astreinte adaptée
8. **Établir le bordereau** exhaustif des pièces
9. **Relire** pour cohérence, références et style

## Informations à collecter

### Sur les parties
- État civil complet (nom, prénom, date et lieu de naissance, nationalité, adresse)
- Pour le défendeur : fonction exacte dans la société
- Coordonnées de l'avocat du demandeur

### Sur la société
- Dénomination sociale
- Forme juridique
- Date de création
- Activité
- Siège social
- Numéro RCS et ville
- Répartition exacte du capital (parts/actions et pourcentages)
- Identité du/des dirigeant(s)

### Sur le litige
- Exercices concernés (généralement les 3 derniers)
- Documents précisément demandés
- Chronologie complète :
  - Dates de chaque demande
  - Mode d'envoi (RAR, email, déplacement sur place)
  - Dates de réception/accusé réception
  - Réponses reçues ou absence de réponse
  - Documents communiqués partiellement (détail des pages)

### Sur le contexte
- Relation entre les parties (ex: anciens pacsés, conflit familial)
- Procédures parallèles en cours
- Décisions de justice antérieures
- Éléments suggérant dissimulation ou mauvaise foi
- Projet de cession de parts

### Sur la procédure
- Tribunal compétent (lieu du siège social)
- Date d'audience souhaitée (minimum 15 jours de délai)
- Montant d'astreinte souhaité
- Montant des frais irrépétibles (article 700)

### Pièces disponibles
- Extrait Kbis
- Statuts
- Correspondances (RAR, emails)
- Convocations aux AG
- Documents communiqués de façon incomplète
- Jugements antérieurs
- Tout élément contextuel pertinent

## Questions types à poser

Pour démarrer la rédaction, poser ces questions à l'utilisateur :

1. Quelle est la forme juridique de la société ? (SARL, SA, SAS, autre)
2. Quel pourcentage de parts/actions le demandeur détient-il ?
3. Qui est le dirigeant visé (nom, fonction) ?
4. Quels exercices sont concernés ? (préciser les années)
5. Quelles démarches ont été faites pour obtenir les documents ? (dates, modalités)
6. Quelles réponses ont été reçues ou pas reçues ?
7. Y a-t-il eu des communications partielles ? (préciser ce qui manquait)
8. Existe-t-il un contexte particulier ? (conflit entre associés, séparation, etc.)
9. Y a-t-il des décisions de justice antérieures impliquant les parties ?
10. Quelles pièces justificatives sont disponibles ?
11. Quel est le tribunal compétent ? (ville du siège social)
12. Quelle date d'audience est visée ?

## Points clés de rédaction

### Style et ton
- Numérotation rigoureuse des sections et sous-sections
- Références systématiques aux pièces entre parenthèses
- Utilisation de "Madame ou Monsieur le Président" (pas de titres alternatifs)
- Mention "de céans" pour désigner le tribunal saisi
- Formule de politesse absente dans le corps (sauf lettres citées)

### Chronologie factuelle
- Dater précisément chaque événement
- Indiquer les modes d'envoi (lettre RAR, email)
- Mentionner l'absence de réponse systématiquement
- Documenter chaque communication parcellaire avec précision

### Caractérisation de l'obstruction
Pour chaque document incomplet, préciser :
- Ce qui était annoncé dans la convocation
- Ce qui a effectivement été joint
- Le nombre de pages communiquées vs. total
- La référence à la pièce justificative

## Adaptation selon la forme sociale

**SARL** : Article L. 223-26
**SA** : Articles L. 225-115 et suivants
**SAS** : Articles L. 227-9 et L. 228-69
**SNC** : Article L. 221-7

Adapter la liste des documents en conséquence.

### Cas de sociétés mères/filiales

Si le demandeur est associé d'une société qui contrôle des filiales, argumenter :
- Sa qualité d'associé de la société mère
- L'article L. 238-1 vise "les personnes intéressées" (portée large)
- Son intérêt à connaître la situation des filiales
- Demander communication pour la société mère ET les filiales contrôlées

## Éléments contextuels renforceurs

Utiles mais non obligatoires :
- Séparation conflictuelle entre associés
- PACS ou union rompue entre associés
- Condamnations judiciaires antérieures pour mauvaise foi
- Impossibilité matérielle de consultation sur place (domicile personnel)
- Création de sociétés concurrentes
- Valorisation de parts en cours (besoin d'information pour cession)
- Pression pour céder rapidement les parts

## Erreurs à éviter

- Ne pas utiliser l'article 145 du CPC (ce skill est uniquement L. 238-1)
- Ne pas oublier la mention "[surlignement en gras ajouté]" après l'article L. 238-1
- Ne pas omettre les références aux pièces
- Ne pas mélanger les articles selon la forme sociale
- Ne pas oublier la formule "SOUS TOUTES RESERVES" à la fin du dispositif
- Ne pas utiliser des montants d'astreinte disproportionnés
- Ne pas oublier les avertissements obligatoires (article 861-2 CPC)
- Vérifier que le délai de convocation est respecté (minimum 15 jours)

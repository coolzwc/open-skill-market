# Règles de calcul des indemnités

## Table des matières

1. [Salaire de référence](#1-salaire-de-référence)
2. [Ancienneté](#2-ancienneté)
3. [Indemnité légale de licenciement](#3-indemnité-légale-de-licenciement)
4. [Indemnité compensatrice de préavis](#4-indemnité-compensatrice-de-préavis)
5. [Congés payés afférents](#5-congés-payés-afférents)
6. [Indemnité pour licenciement sans cause réelle et sérieuse](#6-indemnité-pour-licenciement-sans-cause-réelle-et-sérieuse)

---

### 1. SALAIRE DE RÉFÉRENCE

Le salaire de référence se calcule en prenant le montant le plus favorable entre :
- La moyenne mensuelle des 12 derniers mois de salaire
- 1/3 des 3 derniers mois de salaire (en incluant au prorata les primes annuelles)

### 2. ANCIENNETÉ

L'ancienneté se calcule de la date d'embauche à la date de notification du licenciement (date de la lettre recommandée).

### 3. INDEMNITÉ LÉGALE DE LICENCIEMENT

Formule :
- 1/4 de mois de salaire par année d'ancienneté pour les 10 premières années
- 1/3 de mois de salaire par année d'ancienneté au-delà de 10 ans

Exemple pour 5 ans d'ancienneté et un salaire de référence de 3.000 € :
(3.000 × 1/4) × 5 = 3.750 €

### 4. INDEMNITÉ COMPENSATRICE DE PRÉAVIS

Le préavis dépend de :
- La convention collective applicable
- À défaut, les dispositions du contrat de travail
- À défaut, les usages ou les dispositions légales minimales

Durée légale minimale (article L. 1234-1 du Code du travail) :
- Moins de 6 mois d'ancienneté : pas de préavis légal
- De 6 mois à moins de 2 ans : 1 mois
- 2 ans et plus : 2 mois

Calcul : Salaire mensuel brut × (durée du préavis en mois)

### 5. CONGÉS PAYÉS AFFÉRENTS

10% de l'indemnité compensatrice de préavis

### 6. INDEMNITÉ POUR LICENCIEMENT SANS CAUSE RÉELLE ET SÉRIEUSE

#### Si entreprise < 11 salariés :
- Minimum : 1 mois de salaire
- Maximum : 2 mois par année d'ancienneté
- Plancher absolu : 3 mois de salaire

#### Si entreprise ≥ 11 salariés :
Barème légal (article L. 1235-3-1) - minimum selon ancienneté :
- Moins de 2 ans : 3 mois
- 2 ans à moins de 4 ans : 3 mois
- 4 ans à moins de 6 ans : 4 mois
- 6 ans à moins de 8 ans : 5 mois
- 8 ans à moins de 10 ans : 6 mois
- 10 ans à moins de 12 ans : 7 mois
- 12 ans à moins de 14 ans : 8 mois
- 14 ans à moins de 16 ans : 9 mois
- 16 ans à moins de 18 ans : 10 mois
- 18 ans à moins de 20 ans : 10,5 mois
- 20 ans à moins de 22 ans : 11 mois
- 22 ans à moins de 24 ans : 11,5 mois
- 24 ans à moins de 26 ans : 12 mois
- 26 ans à moins de 28 ans : 12,5 mois
- 28 ans à moins de 30 ans : 13 mois
- 30 ans et plus : 13,5 mois

Maximum : 20 mois de salaire (sauf cas particuliers)

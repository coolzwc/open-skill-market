# Generation Info

- **Source:** `sources/nuxt`
- **Git SHA:** `c9fed804b9bef362276033b03ca43730c6efa7dc`
- **Generated:** 2026-01-28

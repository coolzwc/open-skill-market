# Conseils de rédaction, checklists et stratégie procédurale

## Table des matières

1. [Points clés de rédaction](#points-clés-de-rédaction)
2. [Éléments obligatoires et recommandés](#éléments-obligatoires-et-recommandés)
3. [Pièges à éviter](#pièges-à-éviter)
4. [Montants et délais usuels](#montants-et-délais-usuels)
5. [Checklist finale avant envoi](#checklist-finale-avant-envoi)
6. [Stratégie procédurale](#notes-sur-la-stratégie-procédurale)
7. [Résumé des principes clés](#résumé-des-principes-clés)

---

## Points clés de rédaction

### Style et ton

- **Numérotation rigoureuse** : Sections principales (1., 2.), sous-sections (1.1, 1.2), sous-sous-sections (2.1.1, 2.1.2)
- **Références systématiques aux pièces** : Toujours entre parenthèses après la mention d'un document
- **Titres neutres** : Utiliser "Madame ou Monsieur le Président" (jamais "Votre Honneur" ou autres formules)
- **Juridiction désignée** : Utiliser "de céans" pour le tribunal saisi
- **Désignation des parties** : Utiliser des noms courts cohérents tout au long du document
- **Formulation juridique** : Privilégier "Il est demandé" plutôt que "Nous demandons"
- **Structure argumentaire** : En droit / En l'espèce (systématique)

## Éléments obligatoires et recommandés

### Éléments obligatoires

**Absolument indispensables pour la validité de l'assignation :**

1. ✅ **Identification complète des parties** (état civil, RCS, adresse)
2. ✅ **Date, heure et lieu de l'audience**
3. ✅ **Avertissements obligatoires** (article 853 et 861-2 CPC)
4. ✅ **Extrait Kbis** des parties (Pièces 1 et 2)
5. ✅ **Contrat ou bons de commande** établissant la relation
6. ✅ **Toutes les factures impayées** en pièces
7. ✅ **Grand-livre comptable** du compte client
8. ✅ **Preuve de l'exécution** des prestations/livraisons
9. ✅ **Démonstration du caractère certain, liquide et exigible** de la créance
10. ✅ **Démonstration de l'absence de contestation sérieuse**
11. ✅ **Bordereau exhaustif des pièces**

### Éléments fortement recommandés

**Pour renforcer la solidité du dossier :**

- 📌 **Relances écrites** (courriers recommandés ou emails) prouvant les demandes de paiement
- 📌 **Clause contractuelle** sur les modalités de paiement
- 📌 **Clause pénale ou intérêts de retard** si prévue contractuellement
- 📌 **Bons de livraison signés** ou accusés de réception
- 📌 **Rapport d'activité** ou compte-rendu des prestations effectuées
- 📌 **Preuve de règlements partiels** antérieurs (démontrant la reconnaissance de la dette)
- 📌 **Échanges de correspondances** confirmant la bonne exécution

## Pièges à éviter

❌ **Ne pas confondre** :
- Provision (somme provisionnelle en attente du jugement au fond) vs. condamnation définitive
- Référé (procédure d'urgence) vs. fond (procédure ordinaire)
- Créance certaine vs. créance contestable

❌ **Ne pas oublier** :
- La mention "SOUS TOUTES RESERVES" à la fin du dispositif
- La formule "Lequel se constitue par la présente assignation et ses suites"
- Les mentions "Ci-après désignée" pour identifier les parties
- La capitalisation des intérêts (anatocisme) si demandée

❌ **Ne pas inclure** :
- Des éléments relevant du fond du litige en l'absence de preuve claire
- Des demandes qui nécessiteraient une expertise ou instruction longue
- Des contestations sur la qualité des prestations non documentées par le débiteur

❌ **Ne pas sur-argumenter** :
- Rester factuel dans la section "FAITS"
- Réserver l'argumentation juridique à la section "DISCUSSION"
- Éviter les redites entre les différentes sections

## Montants et délais usuels

**Provisions/Créances :**
- Toute somme justifiée par factures + grand-livre
- Généralement entre quelques milliers et plusieurs dizaines de milliers d'euros
- Pas de limite théorique si créance établie

**Frais irrépétibles (article 700 CPC) :**
- Petites créances (< 10.000 €) : 1.500 à 2.500 €
- Créances moyennes (10.000 - 50.000 €) : 2.500 à 4.000 €
- Grosses créances (> 50.000 €) : 3.000 à 5.000 €

**Intérêts de retard contractuels :**
- Taux ECB + 10 points de pourcentage (minimum légal)
- Ou taux contractuel si supérieur (dans la limite du raisonnable)

**Délai de convocation :**
- Minimum 15 jours entre la signification et l'audience
- Recommandé : 3 à 4 semaines pour permettre la constitution d'avocat

## Checklist finale avant envoi

### Vérifications formelles

- [ ] Identification complète et exacte des parties
- [ ] Numéro RCS correct pour les sociétés
- [ ] Adresses complètes et à jour
- [ ] Date, heure et lieu d'audience précis
- [ ] Coordonnées de l'avocat complètes (toque comprise)
- [ ] Avertissements obligatoires présents (article 853 et 861-2 CPC)
- [ ] Formule "Lequel se constitue par la présente assignation et ses suites"
- [ ] Formule "SOUS TOUTES RESERVES" à la fin du dispositif
- [ ] Signature de l'avocat (si version papier)

### Vérifications de fond

- [ ] Toutes les factures impayées sont listées avec références
- [ ] Le montant total réclamé est correct
- [ ] Les dates d'échéance sont précisées
- [ ] La preuve de l'exécution des prestations est apportée
- [ ] Le grand-livre comptable est en pièce
- [ ] L'absence de contestation sérieuse est démontrée
- [ ] Les relances sont documentées (si effectuées)
- [ ] Les éléments contractuels sont correctement cités
- [ ] L'indemnité forfaitaire de recouvrement est calculée (40 € x nombre de factures)
- [ ] Le type d'avertissement correspond au statut du débiteur (société ou personne physique)
- [ ] Pour entrepreneur individuel : Avis SIRENE en pièce (pas nécessairement Kbis)

### Vérifications juridiques

- [ ] Articles du Code civil correctement cités (1101, 1103, 1104, 1212)
- [ ] Article 873 CPC mentionné (sans "alinéa 2" dans le dispositif)
- [ ] Article L. 441-6 du Code de commerce cité (indemnité forfaitaire)
- [ ] Conditions de certitude, liquidité, exigibilité développées
- [ ] Absence d'exception d'inexécution démontrée
- [ ] Jurisprudence citée si pertinente
- [ ] Demande d'intérêts au taux légal précisée (avec ou sans multiplication)
- [ ] Point de départ des intérêts indiqué (mise en demeure ou dernière facture)
- [ ] Demande d'anatocisme mentionnée (si souhaitée)
- [ ] Indemnité forfaitaire de recouvrement demandée (40 € x nombre factures)
- [ ] Frais article 700 CPC demandés (montant raisonnable)
- [ ] Formulation "somme provisionnelle" utilisée dans le dispositif

### Vérifications des pièces

- [ ] Pièce 1 : Kbis créancier (moins de 3 mois)
- [ ] Pièce 2 : Kbis débiteur (moins de 3 mois)
- [ ] Pièce 3 : Contrat ou bons de commande ou CGV
- [ ] Pièces 4 et suivantes : Toutes les factures impayées
- [ ] Pièce X : Preuve d'exécution (rapport, bons de livraison, etc.)
- [ ] Pièce X+1 : Grand-livre comptable
- [ ] Pièce X+2 : Relances (si applicable)
- [ ] Bordereau des pièces complet et cohérent

### Cohérence globale

- [ ] Les montants sont cohérents dans tout le document
- [ ] Les dates sont cohérentes et chronologiques
- [ ] Les références aux pièces sont exactes
- [ ] Les désignations courtes des parties sont utilisées de façon cohérente
- [ ] Pas de contradiction entre les sections
- [ ] Le dispositif correspond bien aux développements
- [ ] Les demandes sont claires et chiffrées

## Notes sur la stratégie procédurale

### Provision vs condamnation définitive en référé

**Principe clé** : Le juge des référés peut prononcer deux types de décisions :

#### 1. Provision (somme provisionnelle)

**Quand l'utiliser :**
- Créance claire mais pouvant faire l'objet d'une contestation ultérieure
- Montant exact potentiellement discutable
- Souhait de laisser la porte ouverte à une procédure au fond

**Formulation dans le dispositif :**
```
CONDAMNER [le débiteur] à payer à [le créancier] la somme provisionnelle de
[MONTANT] euros TTC...
```

**Avantage :**
- Plus facilement accordée par le juge
- Exécution provisoire de plein droit

**Inconvénient :**
- Le débiteur peut saisir le juge au fond pour contester

#### 2. Condamnation définitive

**Quand l'utiliser :**
- Créance totalement incontestable
- Preuves irréfutables de l'exécution
- Absence totale de contestation du débiteur
- Montant précis et indiscutable

**Formulation dans le dispositif :**
```
CONDAMNER [le débiteur] à payer à [le créancier] la somme de [MONTANT] euros TTC...
```
(noter l'absence du mot "provisionnelle")

**Avantage :**
- Décision définitive qui fait autorité
- Met fin au litige

**Inconvénient :**
- Plus difficile à obtenir (exigence de preuve plus stricte)

#### Recommandation pratique

**Dans la majorité des cas, demander une "somme provisionnelle"** :
- C'est plus prudent juridiquement
- Le juge est plus enclin à l'accorder
- Cela n'empêche pas l'exécution immédiate
- Si le débiteur ne conteste pas au fond, la provision devient définitive

### Quand choisir le référé plutôt que l'injonction de payer

**Avantages du référé :**
- Décision contradictoire = exécution provisoire de plein droit
- Décision motivée = plus difficile à contester
- Possibilité d'obtenir condamnation définitive (pas seulement une ordonnance)
- Permet de traiter des créances plus complexes

**Inconvénients du référé :**
- Coût plus élevé (constitution d'avocat obligatoire)
- Délais plus longs (audience + jugement)
- Nécessite absence de contestation sérieuse

**Quand privilégier le référé :**
- Créance importante (> 10.000 €)
- Relations commerciales établies
- Besoin d'une décision solide et définitive
- Anticipation d'une contestation du débiteur
- Nécessité d'obtenir également condamnation aux dépens et article 700

### Articulation avec une procédure au fond

**Si une procédure au fond existe déjà :**
```
Il est précisé qu'une assignation au fond a été délivrée à [DÉBITEUR] le [date]
devant le Tribunal [de commerce / judiciaire] de [Ville] sous le RG n°[numéro].

Toutefois, compte tenu des délais incompressibles de la procédure au fond et de
l'urgence que présente le recouvrement de la créance d'[CRÉANCIER], la présente
assignation en référé est délivrée afin d'obtenir, dans l'attente du jugement au
fond, une provision égale au montant de la créance qui n'est pas sérieusement
contestable.

La demande formulée devant le juge des référés ne préjuge en rien de la décision
qui sera rendue au fond et ne constitue qu'une mesure provisoire destinée à assurer
la protection des droits d'[CRÉANCIER].
```

**Si le référé est la seule procédure :**

Pas de mention particulière nécessaire. Le référé peut conduire à une condamnation
définitive si la créance est incontestable.

### Gestion du risque de contestation

**Anticipation des contestations potentielles :**

Identifier dès la rédaction les arguments que pourrait invoquer le débiteur :
- Défaut de qualité → Inclure preuves de la qualité + absence de réclamation
- Non-conformité → Inclure bons de livraison signés sans réserve
- Malfaçon → Inclure attestations de satisfaction + usage ultérieur
- Défaut d'autorisation → Inclure bons de commande signés
- Compensation → Démontrer que la créance invoquée n'est pas certaine

**Préparation de l'audience :**

Anticiper les questions du juge :
- Pourquoi le débiteur ne paie-t-il pas ?
- Y a-t-il eu des réclamations ?
- Les prestations ont-elles été intégralement fournies ?
- Le débiteur a-t-il des difficultés financières ?
- Y a-t-il un contentieux parallèle ?

Préparer des réponses claires et factuelles basées sur les pièces.

## Résumé des principes clés

1. **Créance certaine, liquide et exigible** : La trinité indispensable
2. **Absence de contestation sérieuse** : Le critère décisif du référé
3. **Preuve de l'exécution** : Documenter exhaustivement
4. **Grand-livre comptable** : Pièce indispensable
5. **Structure rigoureuse** : En droit / En l'espèce systématiquement
6. **Références aux pièces** : Toujours entre parenthèses
7. **Ton neutre et factuel** : Éviter les jugements de valeur dans les faits
8. **Conclusion ferme** : "Par conséquent, [demande claire]"

## Assistance à la rédaction

Lorsque l'utilisateur demande de rédiger une assignation en référé pour recouvrement
de créance, suivre ce processus :

1. **Poser les questions du workflow** (voir `workflow-collecte.md`)
2. **Collecter tous les documents** disponibles
3. **Rédiger en suivant strictement la structure** (voir `structure-assignation.md`)
4. **Adapter selon le type de créance** (voir `variantes-cas-particuliers.md`)
5. **Vérifier chaque élément** de la checklist finale
6. **Relire pour cohérence** globale et références exactes

**Important** : Ne jamais improviser la structure ou les formulations juridiques.
S'en tenir au modèle de ce skill qui a été validé et qui correspond aux exigences
de la pratique judiciaire française.

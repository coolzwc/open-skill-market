---
name: claudisms-reload
description: Reload Claudisms settings without restarting session
---

!~/.claude/plugins/marketplaces/claudisms/commands/claudisms-reload.sh

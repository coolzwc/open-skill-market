idaapi
======

.. py:module:: idaapi


Attributes
----------

.. autoapisummary::

   idaapi.cvar


Classes
-------

.. autoapisummary::

   idaapi.idaapi_Cvar


Module Contents
---------------

.. py:class:: idaapi_Cvar

   Bases: :py:obj:`object`


.. py:data:: cvar


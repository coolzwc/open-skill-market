# Marginal Value Dual Output Prompt

## Candidate Summary

- **Title**: {{title}}
- **Source**: {{source}}
- **Palace / District**: {{palace}} / {{district}}
- **Tags**: {{tags}}
- **Autonomy Level**: {{autonomy_level}}
- **Curator**: {{actor}}

## Integration Decision

- **Decision**: {{integration_decision}}
- **Confidence**: {{integration_confidence}}

## Intake Content

{{content}}

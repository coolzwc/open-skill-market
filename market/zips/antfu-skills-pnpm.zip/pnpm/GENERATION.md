# Generation Info

- **Source:** `sources/pnpm`
- **Git SHA:** `a1d6d5aef9d5f369fa2f0d8a54f1edbaff8b23b3`
- **Generated:** 2026-01-28

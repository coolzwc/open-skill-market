# Tests for adversarial-spec debate scripts

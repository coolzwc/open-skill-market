# CSS Support

**Status: Experimental — still in active development.**

CSS handling in tsdown is not yet stable. The API and capabilities may change significantly in future releases.

Avoid relying on CSS-related options in production builds until the feature is marked as stable.

# Generation Info

- **Source:** `sources/unocss`
- **Git SHA:** `2f7f267d0cc0c43d44357208aabb35b049359a08`
- **Generated:** 2026-01-28

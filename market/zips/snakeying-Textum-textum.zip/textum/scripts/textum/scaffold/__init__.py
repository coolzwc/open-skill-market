"""Scaffold stage modules."""


# Structure de l'Assignation en Référé

## Table des matières

1. [En-tête](#1-en-tête)
2. [Avertissements obligatoires](#2-avertissements-obligatoires)
3. [Corps de l'assignation : PLAISE A MADAME OU MONSIEUR LE PRESIDENT](#3-corps-de-lassignation--plaise-a-madame-ou-monsieur-le-president)
4. [Dispositif : PAR CES MOTIFS](#4-dispositif--par-ces-motifs)
5. [Bordereau de pièces](#5-bordereau-de-pièces)

---

## 1. En-tête

```
ASSIGNATION EN REFERE
DEVANT MADAME OU MONSIEUR
LE PRESIDENT DU TRIBUNAL [DE COMMERCE / DES ACTIVITES ECONOMIQUES] DE [VILLE]
(Article 873 CPC)

L'AN DEUX MIL [ANNÉE]
ET LE [LAISSER VIDE - sera rempli par l'huissier lors de la signification]

A LA DEMANDE DE

[Identité complète du créancier :]
[Pour une société :]
La société [DENOMINATION], [forme juridique] au capital de [montant] euros,
immatriculée au registre du commerce et des sociétés de [Ville] sous le numéro
[numéro RCS], dont le siège social est sis [adresse complète], prise en la
personne de son représentant légal en exercice, domicilié en cette qualité
audit siège.

[Pour une personne physique :]
Monsieur/Madame [NOM Prénom], né(e) le [date] à [ville (CP)], de nationalité
[nationalité], exerçant l'activité de [activité], immatriculé(e) au registre
du commerce et des sociétés de [Ville] sous le numéro [numéro RCS] [ou : exerçant
sous le numéro SIREN [numéro]], demeurant [adresse complète].

Ayant pour Avocat : [SELARL/SCP/Maître] [Prénom NOM]
Avocat [à la Cour / au Barreau de [Ville]]
[Adresse]
Tél : [téléphone]
[Email]
Vestiaire/Toque : [X XXX]

Lequel se constitue par la présente assignation et ses suites

J'AI L'HONNEUR D'INFORMER

[Identité complète du débiteur avec même structure que ci-dessus]

OU ETANT ET PARLANT A [cette ligne sera complétée par l'huissier]

QU'IL/ELLE EST CONVOQUE(E) LE

[JOUR EN MAJUSCULES] [DATE] [MOIS] [ANNÉE] A [HEURE]
[Chambre des Référés / Référé] [- Salle [numéro] si connue]
[RG n°[numéro] si déjà attribué - sinon laisser vide]

DEVANT LE TRIBUNAL [DE COMMERCE / DES ACTIVITES ECONOMIQUES] DE [VILLE] (Référés)
SITUE [adresse complète du tribunal]
```

**Note importante sur les dates** :
- La ligne "L'AN DEUX MIL VINGT CINQ ET LE" est laissée incomplète (pas de date après "LE")
- Cette date sera complétée par l'huissier au moment de la signification
- La ligne "OU ETANT ET PARLANT A" sera également complétée par l'huissier
- Format de la date d'audience : "MARDI 29 AVRIL 2025 A 10H00" (jour en majuscules)

## 2. Avertissements obligatoires

**IMPORTANT** : Il existe deux versions selon que le débiteur est une société ou une personne physique.

### Version A : Débiteur société (avocat obligatoire)

```
TRÈS IMPORTANT

Conformément aux dispositions de l'article 853 du Code de procédure civile, à cette
audience, vous êtes tenu, sauf disposition contraire, de constituer avocat devant le
tribunal [de commerce / des activités économiques].

Cette formalité est obligatoire.

La constitution de l'avocat emporte élection de domicile.

Faute par vous de comparaître, vous vous exposez à ce qu'une ordonnance soit rendue
contre vous sur la base des seuls éléments fournis par votre adversaire.

Il vous est rappelé que l'article 861-2 du Code de procédure civile dispose :

« Sans préjudice des dispositions de l'article 68, la demande incidente tendant à
l'octroi d'un délai de paiement en application de l'article 1343-5 du code civil
peut être formée par requête faite, remise ou adressée au greffe, où elle est
enregistrée. L'auteur de cette demande doit justifier avant l'audience que l'adversaire
en a eu connaissance par lettre recommandée avec demande d'avis de réception. Les
pièces que la partie invoque à l'appui de sa demande de délai de paiement sont jointes
à la requête.

L'auteur de cette demande incidente peut ne pas se présenter à l'audience, conformément
au second alinéa de l'article 446-1. Dans ce cas, le juge ne fait droit aux demandes
présentées contre cette partie que s'il les estime régulières, recevables et bien
fondées. »

Les pièces sur lesquelles la demande est fondée sont indiquées en fin d'acte selon
bordereau annexé.
```

### Version B : Débiteur personne physique (avocat facultatif)

```
TRÈS IMPORTANT

Vous êtes tenu(e) de comparaître. Vous pouvez cependant vous faire assister ou
représenter par toute personne de votre choix. Le représentant, s'il n'est avocat,
doit justifier d'un pouvoir spécial.

Faute par vous de comparaître ou d'être régulièrement assisté(e) ou représenté(e)
vous vous exposez à ce qu'une ordonnance soit rendue contre vous sur les seuls
éléments fournis par votre(vos) adversaire(s).

Il vous est rappelé que l'article 861-2 du Code de procédure civile dispose :

« Sans préjudice des dispositions de l'article 68, la demande incidente tendant à
l'octroi d'un délai de paiement en application de l'article 1343-5 du code civil
peut être formée par requête faite, remise ou adressée au greffe, où elle est
enregistrée. L'auteur de cette demande doit justifier avant l'audience que l'adversaire
en a eu connaissance par lettre recommandée avec demande d'avis de réception. Les
pièces que la partie invoque à l'appui de sa demande de délai de paiement sont jointes
à la requête.

L'auteur de cette demande incidente peut ne pas se présenter à l'audience, conformément
au second alinéa de l'article 446-1. Dans ce cas, le juge ne fait droit aux demandes
présentées contre cette partie que s'il les estime régulières, recevables et bien
fondées. »

Les pièces sur lesquelles la demande est fondée sont indiquées en fin d'acte selon
bordereau annexé.
```

## 3. Corps de l'assignation : PLAISE A MADAME OU MONSIEUR LE PRESIDENT

### 1. FAITS

#### 1.1. Présentation des Parties

**Structure standard :**

```
La société [DENOMINATION CRÉANCIER] est une [forme juridique] dont l'activité
principale est [description de l'activité].

Ci-après désignée « [NOM COURT] ».

Elle est gérée/présidée/dirigée par [Nom du dirigeant].

Pièce n°1 : Extrait Kbis de [NOM COURT]

[Si le débiteur est une société :]
La société [DENOMINATION DÉBITEUR] a pour activité [description de l'activité].

Ci-après désignée « [NOM COURT] ».

Pièce n°2 : Extrait Kbis de [NOM COURT]

[Si le débiteur est un entrepreneur individuel :]
Monsieur/Madame [NOM Prénom] est entrepreneur individuel dans le domaine de
[activité précise].

Pièce n°2 : Avis de situation SIRENE [ou : Extrait Kbis si disponible]

Ci-après désignées ensemble les « Parties ».
```

**Éléments clés :**
- Identifier clairement les parties avec leurs noms commerciaux courts
- Préciser l'activité de chaque partie
- **Pour les sociétés** : Extrait Kbis obligatoire
- **Pour les entrepreneurs individuels** : Avis de situation SIRENE (ou Kbis si disponible)
- Utiliser la dénomination "les Parties" pour la suite

#### 1.2. Les relations contractuelles entre les Parties

**Structure chronologique :**

Décrire la genèse de la relation commerciale :
- Date et contexte du premier contact
- Nature des prestations ou fournitures convenues
- Date de conclusion du contrat (ou des bons de commande)
- Durée du contrat
- Modalités de paiement convenues

**Formulation type :**

```
Dans le cadre de son activité, la société [DÉBITEUR] a sollicité [CRÉANCIER] pour
[description des prestations/fournitures] courant [année].

C'est dans ce contexte qu'en date du [date], les Parties ont convenu de conclure
un contrat portant sur [objet précis du contrat] pour une durée de [durée].

[Si contrat écrit :]
Ledit contrat prévoit [décrire les principales obligations, notamment le montant
de la rémunération].

Pièce n°3 : Contrat [intitulé] conclu entre [CRÉANCIER] et [DÉBITEUR]

[Si absence de contrat écrit mais bons de commande ou factures acceptées :]
Les prestations se caractérisent par [description]. L'ensemble des prestations a
été commandé par [DÉBITEUR] comme en témoignent [les bons de commande / les
commandes par email / les factures acceptées sans réserve].

Pièce n°3 : Bons de commande [ou autres documents]
```

**Éléments à inclure systématiquement :**
- Date de début de la relation
- Nature précise des prestations ou fournitures
- Montant convenu (forfait, prix unitaire, ou tarif)
- Modalités de paiement (délai, mode de règlement)
- Référence aux pièces contractuelles

#### 1.3. Les manquements contractuels commis par [DÉBITEUR]

**Introduction standard :**

```
En vertu de ce Contrat [ou : Dans le cadre de cette relation commerciale],
[CRÉANCIER] a adressé plusieurs factures à [DÉBITEUR], correspondant aux
échéances [mensuelles / aux prestations réalisées / aux livraisons effectuées].

Malgré la réalisation des prestations assurées par [CRÉANCIER] [ou : la livraison
des marchandises], [DÉBITEUR] a cessé de s'acquitter des factures suivantes :
```

**Pour chaque facture impayée :**

```
- Facture n°[numéro] du [date] : [montant] euros HT, soit [montant] euros TTC ;

Pièce n°[X] : Facture n°[numéro] du [date]
```

**Totalisation :**

```
Soit [nombre] facture(s) pour un total de [MONTANT TOTAL] euros TTC.
```

**Preuves de l'exécution :**

```
Pourtant, [CRÉANCIER] a parfaitement exécuté les obligations qui lui incombaient
au titre du Contrat [ou : de la commande], comme l'atteste [le rapport d'activité /
les bons de livraison / les attestations de réalisation / les échanges de
correspondances].

Pièce n°[X] : [Description de la pièce prouvant l'exécution]
```

**Grand livre comptable (obligatoire) :**

```
L'intégralité des factures impayées figure au sein du grand-livre du compte client
[CRÉANCIER].

Le grand livre d'[CRÉANCIER] fait apparaître que [DÉBITEUR] ne s'est pas
régulièrement acquitté du règlement desdites factures, accumulant un arriéré à
hauteur de [MONTANT TOTAL] euros TTC :

Pièce n°[X] : Grand-livre du compte client [DÉBITEUR]
```

**Relances (recommandé) :**

```
[CRÉANCIER] a réclamé le paiement des factures à plusieurs reprises à [DÉBITEUR]
[par courrier recommandé du [date] / par emails des [dates] / par appels
téléphoniques].

Pièce n°[X] : Relances adressées à [DÉBITEUR]

Malgré ces demandes, les sommes dues au titre du Contrat n'ont jamais été acquittées.
```

**Conclusion factuelle :**

```
Ainsi, compte tenu (2.1) du non-respect des obligations contractuelles de [DÉBITEUR]
et (2.2) de l'absence de contestation sérieuse, [CRÉANCIER] est bien fondé à
solliciter de votre juridiction que [DÉBITEUR] soit condamné à lui régler le
montant des factures impayées [, majorées des intérêts de retard contractuellement
prévus / et des pénalités prévues au contrat].
```

### 2. DISCUSSION

#### 2.1. A titre principal, sur le non-respect des obligations contractuelles par [DÉBITEUR]

##### 2.1.1. Rappel du droit applicable

**En droit :**

Citer les articles pertinents du Code civil :

```
L'article 1101 du Code civil dispose que :

« Le contrat est un accord de volontés entre deux ou plusieurs personnes destiné
à créer, modifier, transmettre ou éteindre des obligations. »

L'article 1103 du Code civil prévoit que :

« Les contrats légalement formés tiennent lieu de loi à ceux qui les ont faits. »

L'article 1104 du Code civil dispose que :

« Les contrats doivent être négociés, formés et exécutés de bonne foi.
Cette disposition est d'ordre public. »

L'article 1212 du Code civil énonce que :

« Lorsque le contrat est conclu pour une durée déterminée, chaque partie doit
l'exécuter jusqu'à son terme. »
```

**Jurisprudence (optionnel mais recommandé) :**

```
La jurisprudence retient qu'un contrat à durée déterminée doit être exécuté jusqu'à
son terme (Civ. 1re, 27 février 2001, n° 98-22.346).

Pendant la durée prévue, les parties sont donc tenues d'exécuter le contrat, chacune
pour la partie lui incombant.
```

##### 2.1.2. Application au cas d'espèce

**En l'espèce :**

**• Sur les obligations contractuelles de [CRÉANCIER]**

```
De son côté, la société [CRÉANCIER] avait pour obligation de [décrire les obligations :
fournir des prestations de services / livrer des marchandises / mettre à disposition
du personnel, etc.].

[Décrire brièvement comment ces obligations ont été remplies]

Les prestations assurées au profit de [DÉBITEUR] se sont déroulées sans la moindre
difficulté.

En effet, [CRÉANCIER] n'a pas manqué de [recenser ses prestations / établir des
bons de livraison / fournir les livrables convenus] auxquelles il était tenu à
compter du [date].

Pièce n°[X] : [Document prouvant l'exécution]

En ce sens, [DÉBITEUR], relancé par [CRÉANCIER], n'a nullement fait part d'une
quelconque contestation sur le principe de la créance d'[CRÉANCIER] ou sur la
qualité des prestations assurées [ou : des marchandises livrées] par [CRÉANCIER].

Pour autant, [DÉBITEUR] a refusé de s'acquitter du solde des factures impayées
relatives au [contrat / aux commandes].

Ainsi, il convient de remarquer qu'[CRÉANCIER] a parfaitement rempli ses obligations
contractuelles, sans que rien ne puisse lui être reproché valablement aujourd'hui.

Il n'existe aucune réclamation ou critique de la part de [DÉBITEUR] et plus
généralement, eu égard aux prestations assurées [ou : aux marchandises livrées],
preuve s'il en fallait de la satisfaction de ce dernier.

Par conséquent, [CRÉANCIER] a parfaitement rempli ses obligations contractuelles.
```

**• Sur les obligations de [DÉBITEUR]**

```
En contrepartie, [DÉBITEUR] avait pour obligation de payer la rémunération convenue
dans le [contrat / bon de commande / conditions générales de vente].

La créance est évidemment fondée compte tenu :

- Du contrat du [date] signé par [DÉBITEUR] [ou : Des bons de commande acceptés] ;
- Des factures émises en accord avec le contrat [ou : avec les tarifs convenus] ;
- Du grand-livre client.

Il est incontestable que [DÉBITEUR] a pris l'engagement ferme et irrévocable de
payer les factures d'[CRÉANCIER] comme en témoignent d'ailleurs [les règlements
intervenus pour les premières factures / l'acceptation des conditions].
```

**Si clause pénale ou intérêts de retard contractuels :**

```
Les factures impayées [portent sur / ne portent que sur] la rémunération des
prestations dispensées par [CRÉANCIER], sans intégrer [ou : en intégrant] les
pénalités en cas de retard de paiement [passé un délai de X jours suivant la date
d'échéance prévue contractuellement].
```

**Conclusion intermédiaire :**

```
Ainsi, aucune contestation ne peut exister sur le caractère vraisemblable du
reliquat de créance d'[CRÉANCIER] s'élevant à hauteur de [MONTANT] euros TTC.

À l'évidence, [DÉBITEUR] ne dispose d'aucun argument pour contester la créance
d'[CRÉANCIER].

[DÉBITEUR] est donc fautif de n'avoir pas respecté pleinement son obligation
contractuelle de paiement, et ce alors même qu'il n'a jamais élevé la moindre
contestation.

En tout état de cause, il n'existe aucune réclamation ou critique de la part de
[DÉBITEUR] et plus généralement, eu égard aux prestations réalisées [ou : aux
marchandises livrées], preuve s'il en fallait de la satisfaction de ce dernier.

Par conséquent, [DÉBITEUR] a manqué à ses obligations contractuelles sans aucune
raison ou justification.
```

#### 2.2. Sur le bien-fondé de la demande en paiement d'[CRÉANCIER]

**Introduction :**

```
Dès lors qu'[CRÉANCIER] a rempli ses obligations contractuelles, sa créance doit
être considérée comme liquide, certaine, exigible et incontestable. En conséquence,
il est bien fondé à s'en prévaloir, judiciairement, à défaut de règlement spontané
par le débiteur, sans que ce dernier puisse objecter une quelconque exception
d'inexécution.
```

##### 2.2.1. Une créance certaine, liquide et exigible

**En droit :**

```
Pour parler de créance, il doit être démontré que celle-ci recouvre trois conditions,
à savoir la certitude, la liquidité et l'exigibilité.
```

**❖ Une créance certaine**

```
S'agissant du caractère certain de la créance, cela signifie qu'elle ne peut pas
être mise en doute. Cette exigence signifie que la créance doit avoir une existence
actuelle et incontestable. Il s'agit donc de la matérialité de la créance : des
marchandises ou des services ont été fournis, en contrepartie de quoi l'on est en
droit d'attendre le prix qui était convenu.

Cette exigence trouve toute son importance en matière de créance contractuelle.
En effet, si un contrat venait à être conclu sans que l'échange des consentements
ne soit parfait (conditions de l'article 1128 du Code civil), les parties auraient
le droit de demander l'annulation de leur engagement et la créance ne présenterait
plus de caractère certain.

Enfin, quelle que soit la nature de la créance (légale, contractuelle,
quasi-contractuelle, délictuelle ou quasi-délictuelle), il appartient au créancier
de prouver le caractère certain de la créance qu'il invoque.

Le caractère certain de la créance est incontesté au sein de la jurisprudence
(Cass. civ. 1re, 3 mai 1966, D. 1966. 649, note J. Mazeaud. – Cass. com., 14 juin
1988, n° 86-15.640 – Cass. com., 26 mars 2013, n° 12-12.204).
```

**❖ Une créance liquide**

```
Ensuite, s'agissant du caractère liquide de la créance, celle-ci doit être estimée
en argent. Cette exigence signifie que le montant de la créance doit pouvoir être
évalué dans une monnaie qui a cours légal (T. com. Lyon, 21 sept. 1951, D. 1952.
26, note H. L. – Cour d'appel de Versailles, 14 octobre 2004, n° 2003-02593).
```

**❖ Une créance exigible**

```
Enfin, la créance ne doit pas être affectée d'un terme suspensif. Cette exigence
signifie que la créance doit être échue par rapport à la date de paiement convenue
(cf. article L. 441-3 du Code de commerce).

C'est seulement à l'issue de cette date de paiement convenue mais non respectée,
que le créancier peut exiger l'application des termes conventionnels agréés entre
les parties, qu'il s'agisse notamment de clauses contractuelles spécifiques ou de
conditions générales de vente afférentes à la détermination du calcul des intérêts
de retard, d'une clause pénale, voire à la mise en œuvre d'une clause de réserve
de propriété, etc.

En tout état de cause, il n'est pas permis au créancier de procéder au recouvrement
d'une créance à terme (sauf en cas de clause acquise de déchéance du terme), ou
dont l'exécution est soumise à condition suspensive.

La jurisprudence est constante sur ce point (Cass. com., 7 janvier 1992, n° 89-20.968.
– Cour d'appel de Versailles, 14 oct. 2004, préc. [supra]. – Cour d'appel de
Versailles, 15 juin 2000, n° 1998-8574).

En outre, la Cour de cassation retient que pour exiger le paiement d'une facture
impayée, le prestataire doit démontrer que les prestations concernées ont bien été
commandées mais également qu'elles ont été réalisées (Cass. com., 10 mars 2021,
n° 19-14888).
```

**En l'espèce :**

```
La créance d'[CRÉANCIER] revêt ces 3 caractères.
```

**❖ Une créance certaine**

```
S'agissant du caractère certain de la créance, celui-ci est établi dans la mesure
où des prestations ont été réalisées par [CRÉANCIER] [ou : des marchandises ont
été livrées], tel qu'il résulte du [contrat / des bons de commande], [de son avenant],
du [rapport d'activité / des bons de livraison / des attestations] d'[CRÉANCIER]
outre les factures adressées à [DÉBITEUR].

Ainsi, la créance d'[CRÉANCIER] est certaine et non contestable.
```

**❖ Une créance liquide**

```
S'agissant du caractère liquide, en l'occurrence il s'agit de factures exprimées
en euros. Cette caractéristique ne fait donc pas difficulté.
```

**❖ Une créance exigible**

```
S'agissant de l'exigibilité, la créance est belle et bien exigible dès lors qu'elle
correspond à des dispositions contractuelles acceptées de manière expresse par les
parties, prévoyant un paiement [à X jours / selon les conditions convenues] au
titre du [contrat / des conditions générales de vente].

En outre, les prestations ont été intégralement réalisées [ou : les marchandises
ont été livrées] de sorte que le paiement est exigible immédiatement [ou : depuis
le [date]], sans délai.

Par conséquent, la créance d'[CRÉANCIER] est certaine, liquide et exigible.
```

##### 2.2.2. Sur l'absence d'exception d'inexécution justifiant le non-paiement de la créance d'[CRÉANCIER]

**En droit :**

```
L'article 1219 du Code civil prévoit que :

« Une partie peut refuser d'exécuter son obligation, alors même que celle-ci est
exigible, si l'autre n'exécute pas la sienne et si cette inexécution est suffisamment
grave. »

L'article 1220 du même code prévoit que :

« Une partie peut suspendre l'exécution de son obligation dès lors qu'il est
manifeste que son cocontractant ne s'exécutera pas à l'échéance et que les
conséquences de cette inexécution sont suffisamment graves pour elle. Cette
suspension doit être notifiée dans les meilleurs délais. »
```

**En l'espèce :**

```
[CRÉANCIER] a toujours exécuté ses obligations contractuelles de bonne foi. Ce qui
n'a jamais été contesté.

À l'inverse, [DÉBITEUR] n'a pas respecté ses engagements contractuels à l'égard
d'[CRÉANCIER].

[CRÉANCIER] est parfaitement en mesure de démontrer que les prestations concernées
ont été exécutées à l'égard de [DÉBITEUR] [ou : que les marchandises ont été livrées],
ainsi que cela a été démontré plus avant.

En outre, [DÉBITEUR] n'a par ailleurs jamais émis le moindre reproche sur la qualité
des services fournis [ou : des marchandises livrées]...

Il n'existe aucune trace de mécontentement, de plainte ou mise en demeure d'avoir
à rectifier le tir, preuve s'il en faut de l'absence de grief à déplorer à l'encontre
d'[CRÉANCIER].

En réalité, [DÉBITEUR] tente vainement d'échapper à son obligation contractuelle,
sans la moindre justification. Aucune exception d'inexécution prévue par les articles
1219 et suivants du Code civil ne peut être mise en exergue dans le cas d'espèce.

Par conséquent, [CRÉANCIER] est bien fondé à solliciter le règlement de ses factures
impayées pour un solde de [MONTANT] euros TTC.
```

##### 2.2.3. Sur l'application de [la clause pénale / des intérêts de retard] stipulé(s) dans le [contrat / les conditions générales de vente]

**[Cette section est optionnelle et ne doit être incluse que si des pénalités ou intérêts de retard sont prévus contractuellement]**

**Si clause pénale ou intérêts de retard :**

```
Le contrat [ou : Les conditions générales de vente] prévoi(en)t notamment la clause
suivante :

[Citer la clause exacte entre guillemets]

[Si la clause est conforme à la loi :]
Cette clause est conforme aux dispositions de l'article L. 441-10 du Code de commerce
qui prévoit que :

« Tout retard dans le paiement des sommes dues au titre des obligations résultant
d'un contrat de vente ou de prestations de services constaté après mise en demeure
[...] entraîne, de plein droit et sans autre formalité, l'obligation pour le débiteur
de payer une pénalité d'un montant égal à celui des intérêts appliqués par la Banque
centrale européenne à son opération de refinancement la plus récente majoré de
10 points de pourcentage. »

[Calculer le montant des pénalités/intérêts si possible]

Par conséquent, [CRÉANCIER] est bien fondé à solliciter la pleine application de
la clause [pénale / relative aux intérêts de retard] prévue contractuellement et
pleinement consentie par [DÉBITEUR].
```

##### 2.2.4. Sur l'indemnité forfaitaire de recouvrement (article L. 441-6 du Code de commerce)

**[Section importante - à inclure systématiquement]**

```
L'article L. 441-6 du Code de commerce dispose :

« En cas de retard de paiement, le créancier professionnel a droit, de plein droit
et sans qu'aucune mise en demeure ne soit nécessaire, à une indemnité forfaitaire
pour frais de recouvrement de 40 euros. »

En l'espèce, [DÉBITEUR] s'est rendu coupable d'un retard de paiement caractérisé
concernant [nombre] facture(s) impayée(s).

En application de l'article L. 441-6 du Code de commerce, [CRÉANCIER] est donc
fondé à solliciter le paiement d'une indemnité forfaitaire de recouvrement d'un
montant de [40 € x nombre de factures] euros, soit 40 euros par facture impayée.

Cette indemnité est due de plein droit, sans qu'aucune mise en demeure préalable
ne soit nécessaire.

Par conséquent, [DÉBITEUR] sera condamné à verser à [CRÉANCIER] la somme de
[montant total] euros au titre de l'indemnité forfaitaire de recouvrement.
```

**Note pratique** : L'indemnité de 40 € par facture s'applique automatiquement même
en l'absence de clause contractuelle. Elle vient s'ajouter à la créance principale
et aux éventuels intérêts de retard.

#### 2.3. Sur l'absence de contestation sérieuse

**[Section très importante - obligatoire]**

```
En droit, l'article 873 alinéa 2 du Code de procédure civile dispose que :

« Dans les cas où l'existence de l'obligation n'est pas sérieusement contestable,
[le président du tribunal de commerce] peut accorder une provision au créancier,
ou ordonner l'exécution de l'obligation même s'il s'agit d'une obligation de faire. »

La Cour de cassation juge de manière constante qu'en matière de référé, le juge
ne peut condamner au paiement d'une somme d'argent que s'il constate l'absence de
contestation sérieuse (Cass. com., 13 octobre 2015, n° 14-18.227).

Une contestation sérieuse s'entend d'une contestation qui repose sur des éléments
de fait ou de droit précis et crédibles, et non sur de simples allégations (Cass.
2e civ., 17 octobre 2019, n° 18-20.306).

En l'espèce, aucune contestation sérieuse ne peut être opposée à la créance
d'[CRÉANCIER] :

- [DÉBITEUR] n'a jamais contesté le principe de la créance ;
- [DÉBITEUR] n'a jamais émis de réserve sur les factures ;
- [DÉBITEUR] n'a jamais fait état d'une quelconque malfaçon [ou : non-conformité
  des marchandises / défaut d'exécution] ;
- [DÉBITEUR] n'a jamais invoqué une quelconque exception d'inexécution ;
- [DÉBITEUR] a [accepté les prestations sans réserve / réceptionné les marchandises
  sans protestation / utilisé les services fournis].

[Si règlements partiels :]
Au demeurant, [DÉBITEUR] a procédé au règlement partiel de certaines factures,
reconnaissant ainsi implicitement le bien-fondé de la créance et l'absence de tout
vice ou défaut.

Par conséquent, en l'absence de toute contestation sérieuse, [CRÉANCIER] est bien
fondé à obtenir la condamnation de [DÉBITEUR] au paiement de sa créance en référé.
```

#### 2.4. Sur les demandes accessoires

##### 2.4.1. Sur la demande relative aux frais et dépens

```
Il serait inéquitable de laisser à la charge de [CRÉANCIER] les frais et dépens
qu'il se voit contraint d'engager afin de préserver ses droits.

[DÉBITEUR] sera donc condamné au paiement de la somme de [montant généralement
entre 2.000 et 5.000] euros par application de l'article 700 du Code de procédure
civile, ainsi qu'aux entiers dépens de la présente instance.
```

##### 2.4.2. Sur la demande d'intérêts au taux légal

**[Section optionnelle si non prévu contractuellement]**

```
Aux termes de l'article 1231-6 du Code civil :

« Les dommages et intérêts dus à raison du retard dans le paiement d'une obligation
de somme d'argent consistent dans l'intérêt au taux légal, à compter de la mise
en demeure. »

En l'espèce, [CRÉANCIER] sollicite la condamnation de [DÉBITEUR] au paiement
d'intérêts au taux légal à compter de [la dernière facture impayée / la date de
la première relance / la date de mise en demeure], ainsi que la capitalisation
des intérêts (anatocisme) conformément à l'article 1343-2 du Code civil.
```

## 4. Dispositif : PAR CES MOTIFS

```
PAR CES MOTIFS

Vu l'article 873 du Code de procédure civile [noter : pas "alinéa 2" dans la formule],
Vu les articles 1101 et suivants du Code civil,
Vu les articles L. 441-10, L. 441-6 et L. 441-3 du Code de commerce [si applicable],
Vu la jurisprudence,
Vu les pièces versées aux débats,

Il est demandé à Madame ou Monsieur le Président du Tribunal [de commerce / des
activités économiques] de [Ville] de :

• JUGER la société [CRÉANCIER] [ou : Monsieur/Madame [NOM]] recevable
  et bien fondée en l'ensemble de ses demandes ;

• JUGER qu'il n'existe aucune contestation sérieuse ;

En conséquence et y faisant droit,

• CONDAMNER [le débiteur] à payer à [le créancier] la somme provisionnelle de
  [MONTANT] euros TTC, avec intérêts au taux légal [multiplié par 3 / ou selon
  clause contractuelle] à compter de [la mise en demeure du [date] / la dernière
  facture impayée du [date]] et avec anatocisme ;

[Si indemnité forfaitaire de recouvrement :]
• CONDAMNER [le débiteur] à payer à [le créancier] la somme provisionnelle de
  [montant] euros au titre de l'indemnité forfaitaire de recouvrement prévue par
  l'article L. 441-6 du Code de commerce ;

[Si clause pénale ou intérêts de retard contractuels :]
• CONSTATER l'absence d'exception d'inexécution justifiant le non-paiement de la
  créance de [le créancier] ;

• CONDAMNER [le débiteur] à payer à [le créancier] [une indemnité correspondant à
  [montant ou formule de calcul] au titre de [la clause pénale / des intérêts de
  retard contractuels]] ;

• CONDAMNER [le débiteur] à verser à [le créancier] la somme de [montant] € au
  titre des dispositions de l'article 700 du Code de procédure civile ;

• CONDAMNER [le débiteur] aux dépens.

SOUS TOUTES RESERVES

ET CE SERA JUSTICE
```

**Points importants :**

1. **"Somme provisionnelle"** : Utilisée en référé car la décision est provisoire et
   n'affecte pas le fond (le débiteur pourrait saisir le juge au fond par la suite).

2. **Intérêts au taux légal** : Possibilité de demander le taux légal multiplié par
   3 si prévu contractuellement ou si retard particulièrement fautif.

3. **Point de départ des intérêts** : Généralement la date de mise en demeure, ou
   à défaut la date de la dernière facture impayée.

4. **Anatocisme** : Capitalisation annuelle des intérêts (article 1343-2 du Code civil).

5. **Indemnité forfaitaire** : 40 € par facture impayée (article L. 441-6 du Code
   de commerce) - systématique et automatique.

6. **Article 873** : Ne pas mentionner "alinéa 2" dans la formule "PAR CES MOTIFS"
   (contrairement à l'en-tête où on peut l'indiquer entre parenthèses).

## 5. Bordereau de pièces

```
Liste des pièces communiquées

Pièce 1. Extrait Kbis de [CRÉANCIER]

Pièce 2. Extrait Kbis de [DÉBITEUR]

Pièce 3. Contrat [intitulé] conclu entre [CRÉANCIER] et [DÉBITEUR]
         [ou : Bons de commande / Conditions générales de vente]

Pièce 4. Facture n°[numéro] du [date]

Pièce 5. Facture n°[numéro] du [date]

[...]

Pièce [X]. [Document prouvant l'exécution : rapport d'activité / bons de livraison
           / attestations / échanges de correspondances]

Pièce [X+1]. Grand-livre du compte client [DÉBITEUR]

[Si relances :]
Pièce [X+2]. Relances adressées à [DÉBITEUR] [courriers recommandés / emails]
```

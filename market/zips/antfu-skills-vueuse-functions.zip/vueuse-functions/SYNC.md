# Sync Info

- **Source:** `vendor/vueuse/skills/vueuse-functions`
- **Git SHA:** `2b8714473501bbdd4a2c7635db40c1b2b6b2fff1`
- **Synced:** 2026-01-31

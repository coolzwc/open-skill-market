"""Story stage modules."""


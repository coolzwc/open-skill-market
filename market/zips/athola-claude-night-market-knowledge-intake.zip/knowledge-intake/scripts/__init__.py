"""Scripts for the knowledge-intake skill."""

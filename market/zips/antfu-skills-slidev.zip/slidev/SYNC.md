# Sync Info

- **Source:** `vendor/slidev/skills/slidev`
- **Git SHA:** `ba4a524fdfa5608b530766dcd37b1651e6996f67`
- **Synced:** 2026-01-31

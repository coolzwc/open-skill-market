# Exemples de Griefs - Notifications de Licenciement

Cette référence contient des exemples de griefs typiques rédigés de manière précise et circonstanciée, inspirés de cas réels. Ces exemples peuvent servir de base ou d'inspiration pour la rédaction de notifications personnalisées.

---

## 1. ABANDON DE POSTE / ABSENCES INJUSTIFIÉES

### Exemple A : Absences répétées non justifiées
```
Nous avons à déplorer de votre part des absences répétées et injustifiées de votre poste de travail.

Plus précisément, vous vous êtes absentée sans autorisation préalable ni justification aux dates suivantes :
- Le 15 mars 2025, vous n'êtes pas venue travailler sans nous prévenir
- Le 22 mars 2025, vous avez quitté votre poste à 14h30 sans autorisation
- Le 5 avril 2025, vous étiez absente toute la journée sans justificatif

Malgré notre courrier de rappel à l'ordre du 8 avril 2025 vous demandant de justifier ces absences, vous n'avez fourni aucune explication.

Ces absences répétées et non justifiées ont désorganisé le service et contraint vos collègues à assurer vos missions en urgence, créant une surcharge de travail importante.
```

### Exemple B : Occupation personnelle pendant les heures de travail
```
Nous avons découvert en octobre de cette année que vous avez à plusieurs reprises quitté votre poste de travail pour vaquer à des occupations personnelles et de nature privée sur vos heures et durant vos jours de travail.

Vous vous êtes donc absentée de votre travail à plusieurs reprises sans motif légitime, sans autorisation de notre part et sans nous en avoir informé.

Notamment, les vérifications effectuées ont révélé que :
- Le 3 octobre 2024, vous avez quitté l'entreprise à 10h30 pour ne revenir qu'à 15h45, sans justification
- Le 7 octobre 2024, vous étiez absente de 9h à 12h30 pour des raisons personnelles
- Le 10 octobre 2024, vous n'étiez pas présente l'après-midi complet

Ces faits ont été constatés par [préciser : badges d'accès, témoignages, etc.] et vous ne pouviez ignorer que ces absences non autorisées constituaient un manquement grave à vos obligations contractuelles.
```

---

## 2. VIOLATION DES RÈGLES DE SÉCURITÉ / MISE EN DANGER

### Exemple : Utilisation d'un véhicule dangereux malgré interdiction
```
Le 10 octobre 2024, vous avez sorti de notre parc automobile un véhicule qui était dans une zone spécifique (véhicule non conforme) appartenant à notre entreprise qui était impropre à la circulation car dangereux, immobilisé pour des raisons de sécurité et devait faire l'objet de réparations avant de pouvoir être remis en service, malgré l'interdiction qui vous avait été faite de l'utiliser, vous mettant vous-même ainsi que les autres usagers de la route en danger.

Les forces de l'ordre ont dû intercepter ce véhicule et avons découvert que vous étiez au volant du véhicule dit dangereux.

Vous êtes volontairement passée outre nos instructions, risquant de causer un accident et de mettre en cause la responsabilité civile et pénale de [NOM ENTREPRISE].

Cette violation délibérée des règles de sécurité constitue une faute d'une particulière gravité compte tenu des risques encourus tant pour vous-même que pour les tiers.
```

---

## 3. INSUFFISANCE PROFESSIONNELLE GRAVE

### Exemple A : Non-réalisation des missions malgré rappels
```
Vous avez été embauché en qualité de délégué médico-technique au sein de notre société par contrat de travail à durée indéterminée à compter du 16 novembre 2020.

Vos fonctions consistaient, notamment, à :
- Visiter des prescripteurs et des établissements de santé de l'usager et d'[NOM ENTREPRISE]
- Veiller à la création et à la mise à jour des protocoles médicaux définis par les prescripteurs qui vous étaient assignés
- Prendre contact avec le médecin prescripteur pour faire part des difficultés particulières rencontrées par un usager
- Assurer le lien entre [NOM ENTREPRISE] et le prescripteur
- Faire le point régulièrement avec les médecins prescripteurs pour s'assurer de notre qualité de service auprès des usagers et de leurs satisfactions
- Vérifier que les demandes particulières d'un prescripteur concernant ses usagers avaient bien été respectées
- Participer à des évènements en tant que représentant d'[NOM ENTREPRISE]
- Participer à la veille concurrentielle et sectorielle
- Rédiger des rapports d'activité
- Élaborer des plans d'actions
- Prendre en charge et suivre des patients sur le secteur qui vous était assigné

Or, votre travail depuis 2023, s'est avéré largement insuffisant.

Vos prises de rendez-vous sont depuis de nombreux mois quasi-inexistantes et vos missions ne sont que partiellement réalisées.

Malgré les demandes et rappels de notre part, votre agenda professionnel reste anormalement vide, compromettant ainsi toute planification adéquate de vos tâches et rendez-vous, ce qui compromet gravement l'efficacité et la coordination du service.

Nous avons également constaté que des rendez-vous ont été ajoutés à votre agenda de manière rétroactive, faussant la traçabilité de votre activité professionnelle.

Les plans d'action demandés pour vous aider, que vous nous avez remis au cours de l'année 2024 sont à la fois insuffisants et inexploitables. En effet, malgré nos demandes répétées, les plans d'actions que vous nous avez fournis étaient très sommaires et ne permettaient pas de mettre en place des solutions concrètes pour améliorer les performances. Nous nous sommes aperçus que les plans d'actions que vous nous avez fournis étaient de simples copier-coller de plans trouvés sur internet.

Vous n'avez donc pas effectué le travail qui vous était demandé, malgré plusieurs demandes de notre part.

Cela a eu une incidence négative sur les objectifs mensuels qui vous étaient assignés et qui n'ont pas pu être réalisés, ni en 2023, ni en 2024, du fait de votre manque de travail, de votre manque d'implication et de l'absence de réalisation de vos missions.
```

### Exemple B : Défaut de supervision et de contrôle
```
Votre fiche de poste de directrice perfusion nutrition vous octroyait le rôle de « Directeur PN, développe et supervise l'ensemble des opérations liées aux soins de perfusion et de nutrition [...] ».

Les dates des prescriptions mises en cause et du contrôle de la CPAM relèvent d'une période pendant laquelle vous étiez en fonction au sein de l'entreprise.

Vous n'avez jamais mis en œuvre une alerte ou bien déployé de correctifs adéquats pour endiguer ces faits.

La révélation de ces faits dans le cadre du contrôle de la CPAM permet également de mettre en lumière l'absence de procédure interne préventive que vous auriez dû développer dans le cadre de vos missions.

Compte tenu des missions contractuelles qui vous incombaient (rappelées ci-dessus aux termes de votre fiche de poste) et de la connaissance des anomalies constatées, votre défaut de réaction constitue un manquement grave à vos obligations professionnelles.
```

---

## 4. VIOLATION D'OBLIGATION CONTRACTUELLE (Clause de mobilité)

### Exemple : Refus de mobilité et sabotage d'entretiens
```
Vous êtes conduit à vous déplacer régulièrement, sur des périodes de plus ou moins longue durée, à des distances variées, conformément à la clause de mobilité qui figure dans votre contrat de travail, auquel vous avez expressément consenti, et qui est rédigée en ces termes :

« Cependant, Monsieur [NOM Prénom] pourra être amené à se déplacer auprès de toutes sociétés clientes de [NOM ENTREPRISE]. Ces déplacements ou missions s'effectueront dans les régions du territoire national où se situent ces sociétés clientes soit : Aquitaine, Auvergne, Languedoc-Roussillon, Provence-Alpes-Côte d'Azur, Rhône-Alpes, Midi-Pyrénées, Île-de-France, Picardie, Bretagne, Pays de la Loire. Ces missions pourront être de durée variable (de quelques jours à plusieurs mois) en fonction de la prestation à accomplir.

Monsieur [NOM Prénom] reconnaît que son attention est spécialement attirée sur la mobilité nécessaire aux collaborateurs d'une société de service telle que [NOM ENTREPRISE] ; Il déclare en avoir bien pris conscience et l'accepte ».

Lors de votre recrutement, votre attention a été particulièrement attirée sur l'exigence de mobilité que supposait votre poste de travail.

Vous avez dès lors donné votre consentement libre et total au principe de la mobilité géographique.

Pour autant, vous avez récemment décidé d'agir en violation de cette obligation contractuelle de mobilité.

En effet, votre mission auprès de la société RTE devait arriver à son terme le 30 septembre 2024.

Au début du mois de septembre, vous avez indiqué être désormais défavorable à toute nouvelle mission impliquant un déplacement éloigné pour raison personnelle.

[...Description des tentatives de négociation et des refus du salarié...]

Nous vous avons organisé un premier entretien en visioconférence avec la société SOPRA STERIA située à Bordeaux le 9 septembre 2024.

Cet entretien s'est avéré être particulièrement médiocre :

- Premièrement, vous avez offert des conditions d'entretien très peu professionnelles : votre caméra de pc ne fonctionnant pas, vous avez finalement utilisé votre téléphone mobile posé de manière nonchalante, le remuant à de multiples reprises pour proposer la prise de vue tronquée de votre visage et enfin la connexion de votre téléphone était très mauvaise nuisant à la fluidité de l'entretien ;

- Secondement, vous avez fait preuve d'un désintérêt manifeste en vous limitant à souligner que la mission correspondait à vos missions précédentes, alors que vous aviez été préparé par mes soins aux réponses à réaliser à ces questions et que vous saviez qu'il était attendu de vous des détails concernant votre parcours professionnel et les points d'intérêts dans la mission proposée.

Votre attitude était primordiale lors de ce premier entretien pour convaincre notre client de vous confier la mission, la motivation du salarié étant un élément déclencheur du partenariat final.

Tout portait à croire que vous sabotiez délibérément l'échange.

[...Description d'autres entretiens sabotés...]

La persistance de votre manque de sérieux et de professionnalisme n'a fait que confirmer que vous sabotiez volontairement les rendez-vous pour ne pas être affecté aux missions et ne pas avoir à vous déplacer.

Vous bâclez les entretiens pour vous assurer que les missions ne vous seront pas proposées, de façon à pouvoir rester dans une situation d'inter-contrat qui est intégralement rémunérée.

Cette attitude est profondément déloyale car elle met en péril nos partenariats commerciaux et la pérennité économique de notre TPE. Au-delà, elle crée un préjudice d'image considérable car elle présente un service dégradé et non-professionnel.

Votre comportement constitue un grave manquement à vos obligations contractuelles.
```

---

## 5. FRAUDE / FALSIFICATION / MALHONNÊTETÉ

### Exemple A : Rendez-vous fictifs
```
Nos vérifications ont tout d'abord établi que de nombreux rendez-vous inscrits dans votre agenda professionnel étaient fictifs. Cette pratique délibérée visait manifestement à donner l'apparence d'une activité soutenue alors que vous ne remplissiez pas vos obligations professionnelles.

L'examen détaillé de votre agenda sur la période de [DATES] révèle que sur [X] rendez-vous mentionnés, [Y] n'ont jamais eu lieu, comme l'attestent [préciser les sources : contacts avec les clients, registres, etc.].

Cette falsification systématique de votre activité constitue une tromperie délibérée destinée à dissimuler votre inactivité et constitue une violation grave du lien de confiance qui doit exister entre employeur et salarié.
```

### Exemple B : Falsification de signatures
```
Lors de la dernière réunion bimensuelle du 31 juillet 2025, l'infirmière coordinatrice a signalé que certaines signatures apposées sur des documents de suivi patients ne correspondaient pas à celles des professionnels de santé concernés.

Cette suspicion a été confirmée lors de la restitution de votre matériel pour assurer la continuité des soins auprès de la Patientèle : l'ordinateur professionnel contenait des documents présentant des signatures manifestement falsifiées.

[Détails précis des documents concernés, dates, comparaisons...]

Cette falsification de documents médicaux constitue non seulement un manquement disciplinaire d'une extrême gravité, mais expose également notre entreprise à des poursuites pénales et engage sa responsabilité civile.
```

### Exemple C : Préparation d'ordonnances sans habilitation
```
L'examen de vos courriels professionnels a révélé des faits accablants : le 30 juin 2025 vous avez préparé et signé une ordonnance au nom de [préciser], alors que vous n'avez aucune habilitation médicale pour ce faire.

Cette pratique, outre qu'elle constitue un exercice illégal de la médecine, engage la responsabilité pénale de notre entreprise et met gravement en danger la santé des patients.

[Précisions sur les circonstances, les documents...]
```

---

## 6. UTILISATION ABUSIVE DE BIENS DE L'ENTREPRISE

### Exemple A : Usage personnel de carte carburant
```
Nous avons également constaté que vous avez utilisé à des fins personnelles la carte carburant mise à votre disposition pour l'exercice exclusif de vos fonctions professionnelles.

L'analyse des relevés de la période du [DATE] au [DATE] fait apparaître :
- [X] pleins effectués les week-ends alors que vous n'aviez pas de mission prévue
- Des pleins réalisés à [LIEU] alors que vous n'aviez aucune raison professionnelle de vous y trouver
- Un montant total de [X]€ correspondant à un usage personnel

Ces faits constituent un détournement de biens de l'entreprise et une violation de votre obligation de loyauté.
```

### Exemple B : Négligence dans la gestion du véhicule professionnel
```
Les investigations ont aussi mis en évidence une négligence grave dans la gestion du véhicule professionnel confié : malgré deux convocations formelles pour le contrôle technique obligatoire (le [DATE] et le [DATE]), vous n'avez pas présenté le véhicule, exposant ainsi l'entreprise à des sanctions administratives et à l'impossibilité d'assurer les missions nécessitant ce véhicule.

Cette négligence répétée et votre défaut de réponse à nos sollicitations démontrent votre absence totale de considération pour les biens qui vous sont confiés et pour les intérêts de l'entreprise.
```

---

## 7. DÉLOYAUTÉ / MANQUEMENT À L'OBLIGATION DE LOYAUTÉ

### Exemple : Tentative de chantage via rupture conventionnelle
```
Le fait que vous proposiez une rupture conventionnelle en lieu et place d'un accord de votre part à la mission proposée, laisse entendre que vous adoptez ce comportement comme moyen de pression aux fins d'obtenir une rupture amiable et financièrement plus avantageuse de votre contrat de travail.

Lors de l'entretien du 3 septembre 2024, vous vous êtes immédiatement braqué et avez exigé une indemnité bien supérieure à ce qui est prévu par la loi ou la convention collective, en insinuant que si nous n'accédions pas à votre demande, rien ne vous empêchait de faire en sorte qu'aucune nouvelle mission ne puisse vous être proposée tout en demeurant rémunéré, soit ce que l'on nomme un inter-contrat.

Cette attitude constitue une forme de chantage incompatible avec la bonne foi qui doit caractériser les relations de travail et démontre votre volonté délibérée de nuire aux intérêts de l'entreprise pour obtenir un avantage financier indu.
```

---

## FORMULES DE TRANSITION ET CONCLUSION

### Entre deux séries de griefs :
```
De plus, [nouveau grief]...
```

```
Par ailleurs, [nouveau grief]...
```

```
Nous avons également constaté que [nouveau grief]...
```

### Formules de gravité :
```
L'ensemble de ces faits constituent des fautes graves rendant impossible la poursuite de votre contrat de travail, même durant le préavis.
```

```
Ces divers manquements graves de votre part nous conduisent à rompre votre contrat de travail avec effet immédiat, sans préavis ni indemnité de licenciement.
```

```
L'analyse des faits révèle un enchaînement de manquements graves et intentionnels, qui, pris isolément comme cumulativement, rendent impossible votre maintien dans l'entreprise.
```

---

## CONSEILS RÉDACTIONNELS

### Pour chaque grief, toujours inclure :
1. **Le fait précis** : Que s'est-il passé exactement ?
2. **La date** : Quand cela s'est-il produit ?
3. **Le contexte** : Dans quelles circonstances ?
4. **La preuve** : Comment avez-vous constaté le fait ?
5. **La conséquence** : Quel impact pour l'entreprise ?
6. **La qualification** : En quoi est-ce une faute ?

### Exemples de formulations de preuves :
- "comme l'attestent les relevés de [...]"
- "ainsi que le confirment les témoignages de [...]"
- "comme en témoignent les documents [...]"
- "les vérifications effectuées ont établi que [...]"
- "l'examen de [...] révèle que [...]"
- "le rapport de [...] fait état de [...]"

### Exemples de formulations de conséquences :
- "Cette situation a eu pour conséquence de [...]"
- "Ces faits ont désorganisé le service en [...]"
- "Votre comportement a créé un préjudice d'image considérable"
- "Ces manquements ont eu une incidence négative sur [...]"
- "Cette attitude expose l'entreprise à [risques juridiques/financiers/etc.]"

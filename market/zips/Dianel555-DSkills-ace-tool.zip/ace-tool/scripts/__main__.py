"""Entry point for running as module: python -m scripts"""

from .ace_cli import main

if __name__ == "__main__":
    main()

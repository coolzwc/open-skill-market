# Step 5: Confirm to user

Tell user the theme was created and show enable snippet:

```css
/* In your main CSS file */
@import "./themes/<theme-name>.css";
```

```html
<!-- On HTML element -->
<html data-theme="theme-<theme-name>">
```

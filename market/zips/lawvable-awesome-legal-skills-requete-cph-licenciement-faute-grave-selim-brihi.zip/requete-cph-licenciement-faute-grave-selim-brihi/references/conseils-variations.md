# Conseils de rédaction et variations

## Table des matières

1. [Jurisprudence clé](#jurisprudence-clé-à-connaître)
2. [Conseils de rédaction](#conseils-de-rédaction)
3. [Points de vigilance](#points-de-vigilance)
4. [Exemple de dialogue avec l'utilisateur](#exemple-de-dialogue-avec-lutilisateur)
5. [Variations selon les situations](#variations-selon-les-situations)
6. [Finalisation](#finalisation)

---

## Jurisprudence clé à connaître

### Sur la faute grave :
- Cass. soc., 27 septembre 2007, n° 06-43867 : définition de la faute grave
- Cass. soc., Pôle 6, 11ème Chambre, 17 janvier 2023, n° 20/07683 : charge de la preuve et impossibilité de requalification par le juge

### Sur les indemnités :
- La jurisprudence constante précise que le juge doit tenir compte de l'ensemble des circonstances (âge, ancienneté, difficultés de reclassement, etc.)

## Conseils de rédaction

1. **Ton et style** : Juridique, formel, objectif. Éviter les émotions excessives tout en restant factuel.

2. **Structuration** : Utiliser des titres, sous-titres et numérotation claire (I, II, III / A, B, C / 1, 2, 3).

3. **Citation des pièces** : Référencer systématiquement les pièces justificatives (Pièce n°X : [Description]).

4. **Articulation droit/faits** :
   - Toujours présenter d'abord le principe EN DROIT
   - Puis l'application EN L'ESPÈCE
   - Cette structure doit être respectée pour chaque point

5. **Précision** : Dates exactes, montants précis, références légales complètes.

6. **Cohérence** : Vérifier la cohérence des montants et des calculs.

7. **Exhaustivité** : Ne pas oublier de demander tous les éléments auxquels le salarié a droit.

8. **Argumentation** : Chaque grief de l'employeur doit être analysé et réfuté de manière structurée.

## Points de vigilance

### 1. Prescription
Vérifier que l'action n'est pas prescrite. En matière de licenciement, le délai de prescription est de 12 mois à compter de la notification du licenciement (article L. 1471-1 du Code du travail).

### 2. Effectif de l'entreprise
L'effectif conditionne le montant des indemnités. Bien vérifier ce point avec le salarié.

### 3. Tentative de résolution amiable
Mentionner si une tentative a été faite, cela renforce la position du salarié.

### 4. Pièces justificatives
S'assurer que toutes les pièces citées sont bien produites et numérotées dans l'ordre.

### 5. Calculs
Vérifier tous les calculs plusieurs fois. Une erreur de calcul peut affaiblir la crédibilité de la demande.

### 6. Convention collective
Vérifier les dispositions spécifiques de la convention collective applicable (préavis, indemnités conventionnelles plus favorables, etc.).

### 7. Procédure
Respecter scrupuleusement les formes et délais de la procédure prud'homale.

## Exemple de dialogue avec l'utilisateur

Collecter les informations de manière interactive :

```
Pour rédiger votre requête devant le Conseil de prud'hommes, j'ai besoin de plusieurs
informations importantes. Je vais vous les demander étape par étape.

PARTIE 1 : VOS INFORMATIONS PERSONNELLES

1. Pourriez-vous me communiquer vos nom et prénom complets ?
2. Votre date et lieu de naissance ?
3. Votre nationalité ?
4. Votre adresse complète actuelle ?
5. Quelle était votre fonction/profession chez cet employeur ?

[Attendre les réponses, puis poursuivre]

PARTIE 2 : INFORMATIONS SUR VOTRE EMPLOYEUR

[etc.]
```

S'assurer d'avoir toutes les informations avant de commencer la rédaction.

## Variations selon les situations

### Si représentation par un avocat :
Inclure le bloc "Ayant pour Avocat" avec les coordonnées complètes.

### Si le salarié n'est pas représenté :
Ne pas inclure le bloc avocat, mais rappeler les règles de représentation dans les avertissements.

### Si griefs multiples :
Traiter chaque grief séparément dans une sous-section dédiée.

### Si irrégularités de procédure :
Créer une section spécifique sur les irrégularités avant l'analyse des griefs.

### Si harcèlement allégué :
Développer une section spécifique sur le harcèlement moral avec les articles L. 1152-1 et suivants du Code du travail.

## Finalisation

Avant de présenter le document final à l'utilisateur :

1. Vérifier la cohérence de toutes les dates
2. Vérifier tous les calculs
3. Vérifier que toutes les pièces citées sont listées dans le bordereau
4. Vérifier l'orthographe des noms et la grammaire
5. Vérifier que toutes les demandes du "PAR CES MOTIFS" correspondent aux développements
6. S'assurer que le document est complet et professionnel

Le document final doit être créé en format .docx dans /home/claude puis copié dans /mnt/user-data/outputs pour être présenté à l'utilisateur.

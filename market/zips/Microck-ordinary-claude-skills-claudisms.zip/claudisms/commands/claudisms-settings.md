---
name: claudisms-settings
description: Manage Claudisms plugin settings
---

!~/.claude/plugins/marketplaces/claudisms/commands/claudisms-settings.sh $ARGUMENTS

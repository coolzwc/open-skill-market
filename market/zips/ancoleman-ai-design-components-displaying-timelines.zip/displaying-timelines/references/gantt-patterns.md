# Gantt Chart Patterns

Project planning Gantt chart implementations with dependencies, drag-and-drop, and resource allocation.

## Task Bar Implementation

[Draggable and resizable task bars]

## Dependency Lines

[Arrow rendering and critical path]

## Resource Allocation

[Resource assignment and visualization]
